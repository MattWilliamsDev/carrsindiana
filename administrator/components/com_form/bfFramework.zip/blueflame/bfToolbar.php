<?php
/**
 * @version $Id: bfToolbar.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

/**
 * I build and display the toolbar for Blue Flame components
 *
 * send, delete, help, cancel, config, apply, back, forward, save, edit, copy, move, new, upload, assign, html, css, publish, unpublish, restore, trash, archive, unarchive, preview, default
 *
 */
final class bfToolbar {
	
	/**
	 * @access private
	 * @var unknown_type
	 */
	private $_buttons = array ();
	
	/**
	 *  The controller
	 *
	 * @var unknown_type
	 */
	var $_controller = null;
	
	/**
	 * This implements the 'singleton' design pattern.
	 */
	public function getInstance($controller) {
		
		static $instance;
		if (! isset ( $instance )) {
			
			$instance = new bfToolbar ( );
			$instance->_controller = $controller;
		}
		return $instance;
	}
	
	/**
	 *
	 *
	 * @return unknown
	 */
	private function _getPrefix() {
		return '<table class="bftoolbar"><tbody><tr>';
	}
	
	/**
	 *
	 *
	 * @return unknown
	 */
	private function _getSuffix() {
		return '</tr></tbody></table>';
	}
	
	/**
	 *
	 *
	 * @param unknown_type $icon
	 * @param unknown_type $xajaxTask
	 */
	public function addButton($icon, $xajaxTask = 'todo', $tip = '') {
		
		switch ($xajaxTask) {
			
			case "xunpublish" :
			case "unpublish" :
				$xajaxTask = "javascript:if(document.adminForm.boxchecked.value==0){alert('" . bfText::_ ( 'Please make a selection from the list to unPublish' ) . "');}else{submitToXAJAX('unpublish')}";
				break;
			
			case "publish" :
			case "xpublish" :
				$xajaxTask = "javascript:if(document.adminForm.boxchecked.value==0){alert('" . bfText::_ ( 'Please make a selection from the list to Publish' ) . "');}else{submitToXAJAX('publish')}";
				break;
			
			case "xedit" :
			case "edit" :
				$xajaxTask = "javascript:if(document.adminForm.boxchecked.value==0){alert('" . bfText::_ ( 'Please make a selection from the list to Edit' ) . "');}else{submitToXAJAX('edit')}";
				break;
			
			case "xremove" :
			case "remove" :
			case "delete" :
			case "xdelete" :
				$xajaxTask = "javascript:if(document.adminForm.boxchecked.value==0){alert('Please select an item to delete');}else{if(confirm('" . bfText::_ ( 'Are you sure you want to delete this item?' ) . "')){submitToXAJAX('remove')}};";
				break;
			
			default :
				$xajaxTask = 'submitToXAJAX(\'' . $xajaxTask . '\');';
				break;
		}
		
		$tip ? $title = bfText::_ ( ucwords ( $icon ) ) . '::' . $tip : $title = ucwords ( $icon );
		$tip ? $hasTip = 'hasTip ' : $hasTip = '';
		
		$html = '<td id="bftoolbar-##ICON##" class="' . $hasTip . 'bfbutton" title="' . $title . '">
		<a class="toolbar" onclick="##ONCLICK##" href="#"><span class="icon-32-##ICON##"></span>##UICON##</a></td>';
		$html = '<td id="bftoolbar-%s" class="%sbfbutton" title="%s">
		<a class="toolbar" onclick="%s" href="#"><span class="icon-32-%s"></span>%s</a></td>';
		//		$html = str_replace ( '##ICON##', $icon, $html );
		//		$html = str_replace ( '##ONCLICK##', $xajaxTask, $html );
		//		$html = str_replace ( '##UICON##', bfText::_ ( ucwords ( $icon ) ), $html );
		$this->_buttons [] = sprintf ( $html, $icon, $hasTip, $title, $xajaxTask, $icon, bfText::_ ( ucwords ( $icon ) ) );
	}
	
	private function _renderButtons() {
		return implode ( "\n", $this->_buttons );
	}
	
	private function toString() {
		$html = $this->_getPrefix ();
		$html .= $this->_renderButtons ();
		$html .= $this->_getSuffix ();
		return $html;
	}
	
	public function render() {
		$this->_controller->setToolbar ( $this->toString () );
	}
	
	public function __toString() {
		$this->render ();
	}
}