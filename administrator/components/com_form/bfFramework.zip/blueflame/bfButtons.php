<?php
/**
 * @version $Id: bfButtons.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

final class bfButtons {
	
	private $_buttons = array ();
	private $_supportedImages = array ('new', 'refresh', 'ok', 'cancel' );
	private $_align = 'left';
	
	public function __construct($align = 'left', $displayStyle = true) {
		$this->_align = $align;
		if ($displayStyle === true) {
			$this->echoStyles ();
		}
	}
	
	public function addButton($id, $onclick, $title, $tip = '', $bfHandler = true) {
		if ($tip == '')
			$tip = bfText::_ ( 'No Help Available' );
		$this->_buttons [] = array ('id' => $id, 'onclick' => $onclick, 'title' => bfText::_ ( $title ), 'tip' => $tip, 'usebfHandler' => $bfHandler );
	}
	
	public function echoStyles() {
		if (@! defined ( '_bf_echoStyles' )) {
			echo $this->_style ();
			define ( '_bf_echoStyles', 1 );
		}
	}
	
	private function _style() {
		global $mosConfig_live_site;
		$html = '<style>
					.commonButton {
						float: ' . $this->_align . ';
					}
					' . $this->_getStyles () . '
					</style>';
		return $html;
	
	}
	
	private function _getStyles() {
		global $mosConfig_live_site;
		$html = '';
		foreach ( $this->_supportedImages as $image ) {
			
			$html .= '#bid-' . $image . ' button {
						background-image:url(' . bfCompat::getLiveSite () . '/' . bfCompat::mambotsfoldername () . '/system/blueflame/view/images/button-' . $image . '.gif);
						padding-left:10px;
					}' . "\n";
		}
		return $html;
	}
	
	public function getHTML() {
		return $this->display ( true );
	}
	
	public function display($r = false) {
		$html = '';
		foreach ( $this->_buttons as $button ) {
			$tooltiptitle = $button ['title'] . '::' . $button ['tip'];
			if ($button ['usebfHandler'] === true) {
				$bfhandler_pre = 'bfHandler(';
				$bfhandler_post = ')';
			} else {
				$bfhandler_pre = '';
				$bfhandler_post = '';
			}
			$html .= "\n" . '<div onclick="' . $bfhandler_pre . $button ['onclick'] . $bfhandler_post . ';" title="' . $tooltiptitle . '" id="bid-' . $button ['id'] . '" class="commonButton hasTip"><button onclick="return false;" name="bname_' . $button ['id'] . '">' . $button ['title'] . '</button><span>' . $button ['title'] . '</span></div>';
		}
		
		if ($r === true) {
			return str_replace ( "\n", "", $html );
		} else {
			echo $html;
		}
	}
	
	public function toString() {
		$this->display ();
	}
}