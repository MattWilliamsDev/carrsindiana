<?php
/**
 * @version $Id: bfError.php 148 2010-01-24 01:15:50Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

final class bfError {

	public static function raiseError($errno='', $title='', $msg = '') {
		global $mainframe;
		$registry = bfRegistry::getInstance ( $mainframe->get ( 'component' ), $mainframe->get ( 'component' ) );
		$registry->setValue ( 'errno', $errno );
		$registry->setValue ( 'error', $msg );

		if (_BF_TEST_MODE == true || defined ( '_IS_XAJAX_CALL' )) {
		} else {
			$error = bfText::_ ( 'Error' );
			$s = '<span class="error-red" style="padding: 5px;width:100%%;"><h1>%s %s - %s!</h1><p>%s</p></span>';
			echo sprintf ( $s, $errno, $error, $title, $msg );
		}

	}

	public static function raiseWarning($errno, $msg) {
		echo '<dl style="background-color: rgb(255, 255, 255);" id="system-message" class="message fade"><dt class="error">Error</dt><dd class="error"><ul>';
		echo '<li>' . $msg . '</li></ul></dd></dl>';
	}

	public function _403($str) {
		$this->_ ( '403', bfText::_ ( 'Access Denied' ), $str );
	}

	public function _($errno, $error, $str) {
		$error_translated = bfText::_ ( 'Error' );
		$s = '<h1>%s $error - %s!</h1><p>%s</p>';
		sprintf ( $s, $errno, $error_translated, $error, $str );
	}
}