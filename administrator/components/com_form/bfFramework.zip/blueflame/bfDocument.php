<?php
/**
 * @version $Id: bfDocument.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

if (! defined ( '_BF_FILEINCLUDED_BFDOCUMENT' ))
	define ( '_BF_FILEINCLUDED_BFDOCUMENT', true );

final class bfDocument {
	
	public static function setGenerator($string) {
		global $mainframe;
		$mainframe->addMetaTag ( 'Page Generator', $string );
	}
	
	public static function addCSS($string) {
		bfDocument::addstylesheet ( $string );
	}
	
	public static function addstylesheet($string) {
		global $mainframe;
		$string = str_replace ( '&', '&amp;', $string );
		$string = '<style type="text/css">@import url(' . $string . ');</style>';
		$mainframe->addCustomHeadTag ( $string );
	}
	
	public static function addCssFromString($string) {
		global $mainframe;
		$string = '<style type="text/css">' . $string . '</style>';
		$mainframe->addCustomHeadTag ( $string );
	}
	
	public static function addScriptFromString($string) {
		global $mainframe;
		$string = '<script type="text/javascript">' . $string . '</script>';
		$mainframe->addCustomHeadTag ( $string );
	}
	
	public static function addscript($string) {
		global $mainframe;
		$string = str_replace ( '&', '&amp;', $string );
		
		$string = '<script src="' . $string . '" type="text/javascript"></script>';
		$mainframe->addCustomHeadTag ( $string );
	}
	
	public static function addjs($string) {
		global $mainframe;
		
		$string = '<script type="text/javascript">' . $string . '</script>';
		$mainframe->addCustomHeadTag ( $string );
	}
	
	public static function addCustomHeadTag($string) {
		global $mainframe;
		$mainframe->addCustomHeadTag ( $string );
	}
	
	public static function setTitle($string) {
		if (_BF_PLATFORM == 'JOOMLA1.5') {
			$doc = JFactory::getDocument ();
			$doc->setTitle ( $string );
		} else {
			global $mainframe;
			$mainframe->setPageTitle ( $string );
		}
	}
	
	/**
	 * Not working for some reason!!!
	 *
	 * @deprecated 
	 */
	public static function addPathway($string, $url = null) {
		return;
	}
	
	public static function addMooTools() {
		global $mainframe;
		$registry = & bfRegistry::getInstance ( $mainframe->get ( 'component' ), $mainframe->get ( 'component' ) );
		bfDocument::addScript ( $registry->getValue ( 'bfFramework_' . $mainframe->get ( 'component_shortname' ) . '.mootools' ) );
		define ( '_BFMOOTOOLS', '1' );
	}
	
	public static function getTemplate() {
		global $mainframe;
		$mainframe->getTemplate ();
	}
	
	/**
	 * @deprecated 
	 */
	public static function initTips() {
	}
}