      <table class="bfadminlist">
        <thead>
          <tr>
            <th colspan="2"><span class="indent bullet-category">{php} echo bfHTML::mooToolTip('Layout Information...','Basic information about the layout');{/php}</span></th>
          </tr>
        </thead>

        <tbody>
          <tr class="row0">
            <td><b>{php} echo bfHTML::mooToolTip('Layout Name','Sets the Layout name');{/php}:</b></td>

            <td><input name="title" type="text" class="flatinputbox" size="73" value="{$TITLE}" /></td>
          </tr>
           <tr class="row0">
            <td valign="top"><b>{php} echo bfHTML::mooToolTip('Layout Description','A friendly description of this template');{/php}:</b></td>

            <td><textarea class="flatinputbox" style="width: 100%; height: 50px;" name="desc" id="desc">{$DESC}</textarea></td>
          </tr>
 		  <tr class="row0">
            <td><b>{php} echo bfHTML::mooToolTip('Layout Scope','The type of object this layout pertains to, i.e., A listing or a category');{/php}:</b></td>

            <td>{$APPLIESTO}</td>
          </tr>
           <tr class="row1">
            <td><b>{php} echo bfHTML::mooToolTip('Template Filename','The full path to the template file');{/php}:</b></td>

            <td>{$FILENAME}</td>
          </tr>
        <thead>
          <tr>
            <th colspan="2"><span class="indent bullet-category"><b>{php} echo bfHTML::mooToolTip('HTML','A detailed HTML for the Layout');{/php}:</b></span></th>
          </tr>
        </thead>

        <tr class="row0">
          <td colspan="2">

          <div id="tip" class="tipdiv" style="margin-bottom:20px;border: 1px solid #ccc; background-color: #fff; padding-left: 10px; padding-right: 10px; padding-bottom: 10px;">

          <h2><img src="{$LIVE_SITE}/{$PLUGIN_DIR}/system/blueflame/view/images/info.png" alt="Tip" align="absmiddle" /> {bfText}Template Structure{/bfText}</h2>
          <p>{bfText}All custom user templates are smarty templates, you can find the{/bfText} <a href="http://www.smarty.net/docs.php" target="_blank">{bfText}full documentation{/bfText} {bfText}for smarty on their website.{/bfText}</a></p>
          <p>{bfText}The place holders can be any of the fields for the item (E.g. Category){/bfText}</p>

          </div>

			<textarea cols="50" style="width: 100%; height: 600px;" name="html" id="html">{$HTML}</textarea></td>
        </tr>
      </table>

      <input type="hidden" name="id" value="{$ID}" />
