<h1>Sorry, Your servers environment is giving us an issue we cant resolve.</h1>

<p>We are trying to set the php include_path</p>

<p>After a lot of research, this is actaully a server configuration issue.</p>

<p>The following bug reports for PHP have caused a change in php behaviour recently: 
</p>
<ul>
<li>http://bugs.php.net/bug.php?id=41561
<li>http://bugs.php.net/bug.php?id=43677
<li>Someone else experiencing the same thing<br />
http://roundcubeforum.net/release-candidate-2/2458-problem-php-5-2-5-ini_set-change-include_path-vital-function.html
</ul>

<p>The problem is, if your webhost enters a non standard directive in the apache configuration file, like this:</p>

<p>php_admin_value include_path "/some/other/path"</p>

<p>Then PHP scripts are then unable to set/unset the include_path from within PHP (This is a VERY common technique for PHP Developers)</p>

<p>This is why you get the message you get below.  Because we are unable to append the include_path with the correct path to the Zend files.</p>

<p>I have managed to replicate this locally - but I have been unable to overcome it and therefore our applications will not work if a system admin has defined the include_path in the apache configuration.</p>

<p>Please forward this information to your webhost and ask them either to </p>

<p>1) remove the custom php_admin_value include_path in the apache configuration</p>

<p>or</p>

<p>2) Add the absolute path to the Zend folder which is "/something/to/your/public_html/plugins/system/blueflame/libs/Zend" to the include path they specify </p>

<p>Kindest regards<br />
Phil.</p>
