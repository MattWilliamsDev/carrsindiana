/* $Id: front_uncompressed.js 74 2009-03-23 20:52:41Z  $ */
function bf_fixTips() {
	var spans = jQuery('div.tool-tip');
	for ( var n = 0; n < spans.length; n++) {
		spans[n].style.visibility = 'hidden';
	}
	var newArray = [];
	allTipElements = jQuery('.hasTip');
	for (i = 0; i < allTipElements.length; i++) {
		var dual = allTipElements[i].title.split('::');
		if (dual[1]) {
			newArray.push(allTipElements[i]);
		}
	}
	if ('undefined' != typeof (Tips)) {
		var myTips = new Tips(newArray, {
			maxTitleChars : 50,
			maxOpacity : 0.9,
			showDelay : 400,
			hideDelay : 400
		});
	}
}
/* set the xajax hideloading message */
function hideLoadingMessage() {
	jQuery('div#loading').hide('slow');
}

function getScrollHeight() {
	var y;
	if (self.pageYOffset) {
		y = self.pageYOffset;
	} else if (document.documentElement && document.documentElement.scrollTop) {
		y = document.documentElement.scrollTop;
	} else if (document.body) {
		y = document.body.scrollTop;
	}
	return parseInt(y, 10);
}

function bf_pageSelect(link) {

	document.location.href = link;
}

function showLoadingMessage() {

	jQuery('div#loading').top(getScrollHeight());
	jQuery('div#loading').show('fast');
}