<?php
/**
 * @version $Id: rsslinks.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined( '_JEXEC' ) or die( 'Restricted access' );

global $mainframe;
$controller->setPageTitle(bfText::_('RSS Feeds'));
$controller->setPageHeader(bfText::_('RSS Feeds'));

/* Create a toolbar, or use a deafult index type toolbar */
$toolbar =& bfToolbar::getInstance($controller);
$toolbar->addButton('help','help', bfText::_('Click here to get help'));
$toolbar->render(true);

/* read the addons out of the framework config file */
$tasks = $registry->getValue('bfFramework_'.$mainframe->get('component_shortname').'.RSS Feeds.Links');
?>
<table class="bfadminlist">
	<thead>
		<tr>
			<th><?php echo bfText::_('Feed Description'); ?></th>
		</tr>
	</thead>
	<tbody>
	<?php
	$row = 0;
	foreach ($tasks as $task){

		if (isset($task[3])){
			$link = bfCompat::sefRelToAbs($task[3]);
		} else {
			$link = bfCompat::sefRelToAbs( '/index2.php?option='.$mainframe->get('component').'&task=rss&format=RSS2.0&no_html=1&pop=1&type='.$task[0]);
		}

		/* display the row */
		echo sprintf('<tr class="row%s">
		<td><span class="bullet-rss biggerblue indent">%s<br /><small>%s</small>
		<br />
		<input type="text" class="flatinputbox rsslinkbox" value="%s" />
		</span></td>
		</tr>',
		$row,
		$task[1],
		$task[2],
		$link
		);

		/* row zebra colors */
		$row = 1 - $row;
	}
?>
	</tbody>
</table>