/* $Id: admin.js 149 2010-01-24 01:17:07Z  $ */
var f = [];
var addLoadingFunction = true;
bfFramework = {
	aloadingTXT : "",
	menuClick : function(b, a) {
		this.aloadingTXT = b;
		this.hideThings();
		bfHandler(a);
	},
	hideThings : function() {
		killTinyMCE();
		if (this.aloadingTXT != "") {
			jQuery("div#bfHeader")
					.html(
							'<img src="../plugins/system/blueflame/view/images/throbber.gif" align="absmiddle" />  ' + this.aloadingTXT);
		} else {
			jQuery("div#bfHeader")
					.html(
							'<img src="../plugins/system/blueflame/view/images/throbber.gif" align="absmiddle" />  ');
		}
		jQuery("div#bf-main-content").hide();
	}
};
function killTinyMCE() {
	if (typeof tinyMCE != "undefined") {
		tinyMCE.triggerSave();
		jQuery.each(tinyMCE.editors, function(a, b) {
			tinyMCE.execCommand("mceRemoveControl", false, a);
		});
	}
}
function selectSubmenuItem(b, a) {
	bfFramework.hideThings();
	bfHandler(a);
}
function highlightSubMenuItem(a) {
	return true;
}
function bfToggleHandler(a, g, e, c) {
	var d = getbfHandler();
	var b = [ a, g, e, c ];
	return xajax.call(d, {
		parameters : b
	});
}
function submitToXAJAX(a) {
	bfFramework.hideThings();
	var b = [];
	b[0] = "x" + a;
	b[1] = xajax.getFormValues("adminForm");
	var c = getbfHandler();
	return xajax.call(c, {
		parameters : b
	});
}
function handleEnter(c, a) {
	var b = a.keyCode ? a.keyCode : a.which ? a.which : a.charCode;
	if (b == 13) {
		return false;
	} else {
		return true;
	}
}
function showConfigTab(b, a) {
	element = document.getElementById("config-document");
	elements = element.getElementsByTagName("DIV");
	for (i = 0; i < elements.length; i++) {
		elements[i].style.display = "none";
	}
	document.getElementById("page-" + b.toLowerCase()).style.display = "block";
}
function xindex() {
	xtra = "";
	returnto = xajax.$("returnto").value;
	var l = xindex.arguments.length;
	for (i = 0; i < l; i++) {
		xtra += ",'" + xindex.arguments[i] + "'";
	}
	if (xtra === "") {
		bfHandler("x" + returnto);
	} else {
		eval("xajax_" + getbfHandler() + "('x" + returnto + "'" + xtra + ");");
	}
}
function jInsertEditorText(a) {
	tinyMCE.execCommand("mceInsertContent", false, a);
}
function insertReadmore() {
	jInsertEditorText('<hr id="system-readmore" />');
}
function orderItem(c, a) {
	if (a == "orderup") {
		var b = "-1";
	} else {
		var b = "1";
	}
	bfToggleHandler("xorderitem", c, b);
}
function hideLoadingMessage() {
}
function init() {
	if (arguments.callee.done) {
		return;
	}
	arguments.callee.done = true;
	if (typeof (xajax) != "undefined") {
		xajax.callback.global.onRequest = function() {
		};
		xajax.callback.global.onResponseDelay = function() {
		};
		xajax.callback.global.onExpiration = function() {
		};
		xajax.callback.global.beforeResponseProcessing = function() {
		};
		xajax.callback.global.onFailure = function() {
		};
		xajax.callback.global.onRedirect = function() {
		};
		xajax.callback.global.onSuccess = function() {
		};
		xajax.callback.global.onComplete = function() {
		};
	}
	if (typeof xajax != "undefined") {
		if (addLoadingFunction === true) {
			xajax.loadingFunction = function() {
			};
		}
	}
}
function bf_fixTips() {
	var c = jQuery("div.tool-tip");
	for ( var e = 0; e < c.length; e++) {
		c[e].style.visibility = "hidden";
	}
	var b = [];
	allTipElements = jQuery(".hasTip");
	for (i = 0; i < allTipElements.length; i++) {
		var d = allTipElements[i].title.split("::");
		if (d[1]) {
			b.push(allTipElements[i]);
		}
	}
	var a = new Tips(b, {
		maxTitleChars : 50,
		maxOpacity : 0.9,
		showDelay : 400,
		hideDelay : 400
	});
}
function hideLoadingModalTB() {
	jQuery("#TB_imageOff").unbind("click");
	jQuery("#TB_overlay").unbind("click");
	jQuery("#TB_closeWindowButton").unbind("click");
	jQuery("#TB_window").fadeOut("fast", function() {
		jQuery("#TB_window,#TB_overlay,#TB_HideSelect").remove();
	});
	jQuery("#TB_load").remove();
	if (typeof document.body.style.maxHeight == "undefined") {
		jQuery("body", "html").css( {
			height : "auto",
			width : "auto"
		});
		jQuery("html").css("overflow", "");
	}
}
function showLoadingModelTB() {
	if (typeof document.body.style.maxHeight === "undefined") {
		jQuery("body", "html").css( {
			height : "100%",
			width : "100%"
		});
		jQuery("html").css("overflow", "hidden");
		if (document.getElementById("TB_HideSelect") === null) {
			jQuery("body")
					.append(
							"<iframe id='TB_HideSelect'></iframe><div id='TB_overlay'></div><div id='TB_window'></div>");
			jQuery("#TB_overlay").click(tb_remove);
		}
	} else {
		if (document.getElementById("TB_overlay") === null) {
			jQuery("body").append(
					"<div id='TB_overlay'></div><div id='TB_window'>");
		}
	}
	jQuery("#TB_load").show();
}
if (document.addEventListener) {
	document.addEventListener("DOMContentLoaded", init, false);
}
window.onload = init;
