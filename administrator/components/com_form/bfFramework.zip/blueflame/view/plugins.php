<?php
/**
 * @version $Id: plugins.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined( '_JEXEC' ) or die( 'Restricted access' );

$controller->setPageTitle(bfText::_('Additional Free Addons'));
$controller->setPageHeader(bfText::_('Additional Free Addons'));

/* Create a toolbar, or use a deafult index type toolbar */
$toolbar =& bfToolbar::getInstance($controller);
$toolbar->addButton('help','help', bfText::_('Click here to get help'));
$toolbar->render(true);

/* read the addons out of the framework config file */
$mambots = $registry->getValue('bfFramework_'.$mainframe->get('component_shortname').'.addons.plugins');
$modules = $registry->getValue('bfFramework_'.$mainframe->get('component_shortname').'.addons.modules');

bfLoad('bfButtons');

$buttons = new bfButtons();


//$buttons->display();
?>
<table class="bfadminlist">
	<thead>
		<tr>
			<th><?php echo bfText::_('Addon Title'); ?></th>
		    <th width="80"><?php echo bfText::_('Name'); ?></th>
		    <th width="80"><?php echo bfText::_('Type'); ?></th>
		    <th width="80"><?php echo bfText::_('Status'); ?></th>
			<th width="120"><?php echo bfText::_('Toggle'); ?></th>
		</tr>
	</thead>
	<tbody>
	<?php
	$row = 0;
	if (count($mambots)){
		foreach ($mambots as $mambot=>$desc){

			/* Get the mambot type */
			$parts = explode('.',$mambot);
			$type = $parts[0];

			/* Is it already installed ? */
			$instaled = bfUtils::isMambotInstalled($mambot);
			$status = bfText::_($instaled ?  'Installed' : 'Uninstalled');
			$class = $instaled ?  'green' : 'red';


			/* Generate the correct xajax task and button */
			$toggle = bfHTML::PluginInstallertoggle('mambot', $mambot);



			/* display the row */
			echo sprintf('<tr class="row%s"><td><span class="bullet-plugin">%s</span></td><td>%s</td><td>%s</td><td id="status-%s" class="%s">%s</td><td id="toggle-%s">%s</td></tr>',
			$row,
			bfText::_($desc),
			$mambot,
			bfText::_('mambot'),
			str_replace('.','_',$mambot),
			$class,
			$status,
			str_replace('.','_',$mambot),
			$toggle
			);

			/* row zebra colors */
			$row = 1 - $row;
		}
	}
	if (count($modules)){
		foreach ($modules as $module=>$desc){

			/* Get the mambot type */
			$parts = explode('.',$module);
			$type = $parts[0];

			/* Is it already installed ? */
			$instaled = bfUtils::isModuleInstalled($module);
			$status = bfText::_($instaled ?  'Installed' : 'Uninstalled');
			$class = $instaled ?  'green' : 'red';

			/* Generate the correct xajax task and button */
			$toggle = bfHTML::PluginInstallertoggle('module', $module);

			/* display the row */
			echo sprintf('<tr class="row%s"><td><span class="bullet-plugin">%s</span></td><td>%s</td><td>%s</td><td id="status-%s" class="%s">%s</td><td id="toggle-%s">%s</td></tr>',
			$row,
			bfText::_($desc),
			$module,
			bfText::_('module'),
			str_replace('.','_',$module),
			$class,
			$status,
			str_replace('.','_',$module),
			$toggle
			);

			/* row zebra colors */
			$row = 1 - $row;
		}
	}

	/**
			 * The fish compatibility
			 */
	$fish_enabled = false;
	$filename = _BF_JPATH_BASE . DS . bfCompat::mambotsfoldername() . DS . 'system' . DS . 'jfdatabase.systembot.php';
	if (file_exists($filename)){
		$fish_enabled = true;
	}

	if ($registry->getValue('joomfish_compatible', false) === true && $fish_enabled ===true){
		/* Get the mambot type */
		$type = 'fish';

		/* Is it already installed ? */
		$instaled = false; //bfUtils::isModuleInstalled($module);
		$module = '';


		$status = bfText::_($instaled ?  'Installed' : 'Uninstalled');
		$class = $instaled ?  'green' : 'red';

		/* Generate the correct xajax task and button */
		//		$toggle = bfHTML::PluginInstallertoggle('module', $module);

		$title = '<img src="components/com_joomfish/images/fish.png" align="left" />'.bfText::_('Joom!Fish Content Elements') . '<sup>BETA</sup>';
		$desc = bfText::_('To enable Joom!Fish integration copy the files in <br />')
		. '/components/'. $mainframe->get('component') .'/addons/fish/' . '<br />' . bfText::_('to the Joom!Fish content elements folder.');
		/* display the row */
		echo sprintf('<tr class="row%s"><td><span class="bullet-plugin">%s</span><br/ >%s</td><td>%s</td><td>%s</td><td id="status-%s" class="%s">%s</td><td id="toggle-%s">%s</td></tr>',
		$row,
		$title,
		$desc,
		'XML File',
		bfText::_('XML File'),
		str_replace('.','_',$module),
		'',
		bfText::_('Manual Install Only'),
		str_replace('.','_',$module),
		''//$toggle
		)
		;

		/* row zebra colors */
		$row = 1 - $row;
	}
?>
	</tbody>
</table>