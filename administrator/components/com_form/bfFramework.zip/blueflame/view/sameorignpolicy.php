<?php
/**
 * @version $Id: sameorignpolicy.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<style>
.warning{
text-align: left;
width: 500px;
background-color: #fff;

}
</style>

<div class="warning">
<h1>Hi, We need you to read this...</h1>

<p>At the moment you are accessing this webpage using:<br />
<br />
http://###HOST###

</p>

<p>
Beacause of a browser security policy (called <a href="http://en.wikipedia.org/wiki/Same_origin_policy" target="_blank">Same Origin Policy</a>) dating back to Netscape days, the complex
 AJAX and Javascript contained in this component will not work unless you access this website using the <b>exact same</b>
 domain name as you have configured in configuration.php. Your joomla configuration.php contains your live site as:
<br /><br />
<a href="###LIVESITE###/administrator/">###LIVESITE###</a>

 <br /><br />
 The most common problem is that you have configured www.domain.com and you are accessing now with domain.com.
 These two are considered by your browser to be totally different sites and thus the security stops you running javascript between them.
</p>

<h2>The solution - easy!</h2>
<p>
In order to proceed just retype the correct web address (Probably: <a href="###LIVESITE###/administrator/">###LIVESITE###/administrator/</a>) into your web browser

</p>
</div>
