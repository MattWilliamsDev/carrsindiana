<?php
/**
 * @version $Id: bfFramework.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );
defined('_BF_BFFRAMEWORK_INLUDED') or define('_BF_BFFRAMEWORK_INLUDED',1);

/* Tweak baby! */
require (dirname(__FILE__) . DS . 'bfTweaks.php');

define('_BF_JPATH_LIBRARIES', dirname(__FILE__) . DS . 'libs');

/* initialize test mode */
if (! defined('_BF_TEST_MODE')) {
    define('_BF_TEST_MODE', false);
} else {
    /* set up test env */
//    global $mainframe;

}



/* make our compatibility layer active */
if (! class_exists('bfCompat'))
    require (dirname(__FILE__) . DS . 'bfCompat.php');

/* Set our defines */
require (dirname(__FILE__) . DS . 'bfDefine.php');

/* allow loading of bfLibs by bfLoad(); */
require (dirname(__FILE__) . DS . 'bfLoader.php');

/* am I an admin user ? */
$isAdmin = bfCompat::isAdmin($mainframe);

/* The following ORDER is VERY important to fulfil dependancies! */
bfLoad('bfDatabase');
bfLoad('bfRedirect');
bfLoad('bfText');
bfLoad('bfString');
bfLoad('bfError');
bfLoad('bfLog');
bfLoad('bfRegistry');
bfLoad('bfRequest');
bfLoad('bfInputFilter');
bfLoad('bfString');
if ($isAdmin)
    bfLoad('bfToolbar');
if ($isAdmin)
    bfLoad('bfSubmenu');
bfLoad('bfButtons');
bfLoad('bfTable');
bfLoad('bfUser');
bfLoad('bfHTML');
bfLoad('bfDocument');
bfLoad('bfUTF8');
bfLoad('bfCache');
bfLoad('bfModel');
bfLoad('bfController');

//global $mainframe;

/* Make Sure we register Zend */
$isWin = (substr(PHP_OS, 0, 3) == 'WIN');
$sep = $isWin ? ';' : ':';
$r = ini_set ( 'include_path', ini_get ( 'include_path' ) . $sep . _BF_JPATH_LIBRARIES . $sep . _BF_JPATH_LIBRARIES . DS . 'Pear');
if (!$r) {
	include('view/error.include_path.php');
	die;
}

/* Set up our registry and namespace */
$r = $mainframe->get('component');

$registry = bfRegistry::getInstance($r, $r);
//return;
/* load utils */
bfLoad('bfUtils');

/* include configuration class */
bfLoad('bfConfig');

/* @var $bfConfig bfconfig */
$bfConfig = bfConfig::getInstance($mainframe->get('component'));

bfLoad('bfSession');

/* include the framework config */
require_once (JPATH_ROOT . DS . 'components' . DS . $mainframe->get('component') . DS . 'etc' . DS . 'framework.config.php');

/* start our session */
$session = bfSession::getInstance($mainframe->get('component'));

/* set up our user */

bfText::setDebug($mainframe->get('component'));
/* Set our Security Levels and checks */
bfLoad('bfSecurity');