<?php
/**
 * @version $Id: bfRedirect.php 138 2009-12-27 17:21:29Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

final class bfRedirect {
	
	static public function _($url, $msg = '') {
		if (! defined ( '_IS_XAJAX_CALL' )) {

			if (trim ( $msg )) {
				if (strpos ( $url, '?' )) {
					$url .= '&mosmsg=' . urlencode ( $msg );
				} else {
					$url .= '?mosmsg=' . urlencode ( $msg );
				}
			}
			
			if (headers_sent ()) {
				echo "<script>document.location.href='$url';</script>";
			} else {
				@ob_end_clean (); // clear output buffer
				header ( 'HTTP/1.1 301 Moved Permanently' );
				header ( "Location: " . $url );
			}
		
		} else {
			throw new Exception ( 'Cant use bfRedirect through xajax!!!' );
		}
	}
}

function bfRedirect($url, $msg = '') {
	return bfRedirect::_ ( $url, $msg );
}