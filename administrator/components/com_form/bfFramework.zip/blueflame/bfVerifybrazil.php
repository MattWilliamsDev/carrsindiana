<?php
/**
 * @version $Id: bfVerifybrazil.php 139 2010-01-03 20:45:41Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

/*
* Classe para validação de CNPJ
* Copyright (c) Sebastião Farias Júnior 2002
* Belém/PA
* E-mail: overond@yahoo.com
* Licença GNU
* Modo de usar:
* $cnpj="61427258000759";
* $oCnpj = new cnpj;
* if ($oCnpj->verfica_cnpj($cnpj)==1){
* echo "CNPJ valido";
* }
* else{
* echo "CNPJ invalido";
* }
*/
class cnpj {
	var $expressao_regular_de_cnpj = "[0-9]{2,3}\\.?[0-9]{3}\\.?[0-9]{3}/?[0-9]{4}-?[0-9]{2}";
	
	/**
	 * cnpj::clim()
	 * Tiras espaços e tabulações
	 * @param $cnpj
	 * @return
	 */
	function clim($cnpj) {
		$cnpj = preg_replace ( "[ ]*[    ]*", "", $cnpj );
		return $cnpj;
	}
	
	/**
	 * cnpj::isNUMB()
	 * Verifica se a pessoa digitou somente número e verifica se tem 14 digitos
	 * @param $cnpj
	 * @return
	 */
	function isNUMB($cnpj) {
		//1 - somente número e tem 14 digitos
		//0 - não e só número ou não tem 14 digitos
		

		$digitos = preg_replace ( "[-. \t]", "", $cnpj );
		if (! preg_match ( "/^" . $this->expressao_regular_de_cnpj . "\$/", $digitos )) {
			return 0;
		}
		return 1;
	}
	
	/**
	 * cnpj::teste_cnpj()
	 * Função que verifica se o CNPJ é valido ou não
	 * @param $cnpj
	 * @param $x
	 * @return
	 */
	function teste_cnpj($cnpj, $x) {
		//1 - cnpj válido
		//0 - cnpj inválido
		$VerCNPJ = 0;
		$ind = 2;
		$tam;
		for($y = $x; $y > 0; $y --) {
			$VerCNPJ += ( int ) substr ( $cnpj, $y - 1, 1 ) * $ind;
			if ($ind > 8) {
				$ind = 2;
			} else {
				$ind ++;
			}
		}
		$VerCNPJ %= 11;
		if (($VerCNPJ == 0) || ($VerCNPJ == 1)) {
			$VerCNPJ = 0;
		} else {
			$VerCNPJ = 11 - $VerCNPJ;
		}
		if ($VerCNPJ != ( int ) substr ( $cnpj, $x, 1 )) {
			return 0;
		} else {
			return 1;
		}
	}
	
	/**
	 * cnpj::verfica_cnpj()
	 * Função chamadora para validação do CNPJ
	 * @param $cnpj
	 * @return
	 */
	function verfica_cnpj($cnpj) {
		//1 - cnpj válido
		//0 - cnpj inválido
		$cnpj = $this->clim ( $cnpj );
		if ($this->isNUMB ( $cnpj ) != 1) {
			return 0;
		} else {
			$x = strlen ( $cnpj ) - 2;
			if ($this->teste_cnpj ( $cnpj, $x ) == 1) {
				$x = strlen ( $cnpj ) - 1;
				if ($this->teste_cnpj ( $cnpj, $x ) == 1) {
					return 1;
				} else {
					return 0;
				}
			} else {
				return 0;
			}
		}
	}
}

/*
* Classe para validação de CNPJ
* Copyright (c) Sebastião Farias Júnior 2002
* Belém/PA
* E-mail: overond@yahoo.com
* Licença GNU
* Modo de usar:
* $oCpf = new cpf;
* if ($oCpf->verifica_cpf($cpf)){
* echo "CPF valido";
* }
* else{
* echo "CPF invalido";
* }
*/
class cpf {
	var $expressao_regular_de_cpf = "[0-9]{3}\\.?[0-9]{3}\\.?[0-9]{3}-?[0-9]{2}";
	
	/**
	 * cpf::clim()
	 * Tiras espaços e tabulações
	 * @param $cnpj
	 * @return
	 */
	function clim($cpf) {
		$cpf = preg_replace ( "[ ]*[    ]*", "", $cpf );
		return $cpf;
	}
	
	/**
	 * cpf::isNUMB()
	 * verifica se digitou so numeros e tem 11 digitos
	 * @param $cnpj
	 * @return
	 */
	function isNUMB($cpf) {
		//1 - somente número e tem 11 digitos
		//0 - não e só número ou não tem 11 digitos
		$digitos = preg_replace ( "[-. \t]", "", $cpf );
		if (! preg_match ( "/^" . $this->expressao_regular_de_cpf . "\$/", $digitos )) {
			return 0;
		}
		return 1;
	}
	
	/**
	 * cpf::checaCPF()
	 * Função que verifica se o cpf é valido ou não
	 * @param $cpf
	 * @return
	 */
	function checaCPF($cpf) {
		if (strlen ( $cpf ) != 11 || $cpf == "00000000000" || $cpf == "11111111111" || $cpf == "22222222222" || $cpf == "33333333333" || $cpf == "44444444444" || $cpf == "55555555555" || $cpf == "66666666666" || $cpf == "77777777777" || $cpf == "88888888888" || $cpf == "99999999999")
			return 0;
		$soma = 0;
		for($i = 0; $i < 9; $i ++)
			$soma += ( int ) (substr ( $cpf, $i, 1 )) * (10 - $i);
		$resto = 11 - ($soma % 11);
		if ($resto == 10 || $resto == 11)
			$resto = 0;
		if ($resto != ( int ) (substr ( $cpf, 9, 1 )))
			return 0;
		$soma = 0;
		for($i = 0; $i < 10; $i ++)
			$soma += ( int ) (substr ( $cpf, $i, 1 )) * (11 - $i);
		$resto = 11 - ($soma % 11);
		if ($resto == 10 || $resto == 11)
			$resto = 0;
		if ($resto != ( int ) (substr ( $cpf, 10, 1 )))
			return 0;
		return 1;
	}
	
	/**
	 * cpf::verifica_cpf()
	 * Função chamadora para validação do cpf
	 * @param $cpf
	 * @return
	 */
	function verifica_cpf($cpf) {
		$cpf = $this->clim ( $cpf );
		if ($this->isNUMB ( $cpf ) != 1) {
			return 0;
		}
		
		if ($this->checaCPF ( $cpf )) {
			return 1;
		} else {
			return 0;
		}
	}
}