<?php
###############################################
# PU Arcade System Bot		              #
# Copyright (C) 2008 by Pragmatic Utopia      #
# Homepage   : www.pragmaticutopia.com        #
# Email      : puarcade@pragmaticutopia.com   #
# Version    : 2.2                            #
# License    : Released under GPL 	      #
#	     				      #
# Based on JoomGames by Pedro Simões         #
# www.tudodoido.com - Thanks for sharing!     #
###############################################

defined( '_VALID_MOS' ) or die( 'Restricted access' );

// register the entry point variable to use the flashgamehandler
define( "PUARCADE_ENTRY_POINT", 1);

// define the class which handles all of this for us.
if (file_exists('components/com_puarcade/flashgamehandler.php')){
require("components/com_puarcade/flashgamehandler.php");
}

// register this mambit to fire on start....
$_MAMBOTS->registerFunction( 'onStart', 'PUArcadeSys' );
	
function PUArcadeSys(){
	

	// v3 support
	$act = strtolower( mosGetParam( $_REQUEST, "act"));	
	if($act == "arcade"){
		
		// turn on the score submission
		$myhandler = new flashgamehandler_v3();
		$myhandler->start_session();
		$myhandler->handle_score_submit();
		
		exit;
		
	}
		
	// v32 support
	$auto = strtolower( mosGetParam( $_REQUEST, "autocom"));
	$sessdo = strtolower( mosGetParam( $_REQUEST, "do"));
	if($auto == "arcade"){
		
		// turn on the flash handler
		$myhandler = new flashgamehandler_v32();
		$myhandler->start_session();
		
		switch($sessdo){
			
			// called by flash game at start of the session.
			case 'sessionstart' :
				$myhandler->handle_session_start();
				break;
			
			case 'verifyscore' :
				$myhandler->handle_score_request();
				break;
				
			case 'savescore' :
				$myhandler->handle_score_submit();
				break;
				
		}
		
		// ensure we go no further..
		exit;
	}
	
	
	/* 
	 * pnflashgames can either be submitted by the url or via postdata it seems!
	 */
	$module = strval( strtolower( mosGetParam( $_REQUEST, 'module' ) ) );
	if ( $module == 'pnflashgames' ) {
		
		// turn on the flash handler
		$myhandler = new flashgamehandler_pnflash();
		$myhandler->start_session();
		// submit the score...
		$myhandler->handle_score_submit();

		// ensure we go no further..
		exit;

	}

}
 
?>