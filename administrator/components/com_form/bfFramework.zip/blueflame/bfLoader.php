<?php
/**
 * @version $Id: bfLoader.php 139 2010-01-03 20:45:41Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

final class bfImport {

	private $_included = array ( );

	public function bfInclude($lib) {
		global $mainframe;
		if (! in_array ( $lib, $this->_included )) {

			if (preg_match ( '/helper/', $lib )) {
				$file = bfCompat::getAbsolutePath () . DS . 'components' . DS . $mainframe->get ( 'component' ) . DS . 'lib' . DS . $lib . '.php';
				if (file_exists ( $file )) {
					if (! require ($file)) {
						echo $file;
						echo "<BR>" . bfText::_ ( 'COULD NOT INCLUDE LAST FILE' );
					}
				} else {
					echo $file;
					echo "<BR>" . bfText::_ ( 'COULD NOT INCLUDE LAST FILE' );
				}
				return;
			}

			if (preg_match ( '/model./', $lib )) {
				$file = bfCompat::getAbsolutePath () . DS . 'components' . DS . $mainframe->get ( 'component' ) . DS . 'model' . DS . strtolower ( str_replace ( 'model.', '', $lib ) ) . '.php';
				if (file_exists ( $file )) {
					if (! require ($file)) {
						echo $file;
						echo "<BR>" . bfText::_ ( 'COULD NOT INCLUDE LAST FILE' );
					}
				} else {
					echo $file;
					echo "<BR>" . bfText::_ ( 'COULD NOT INCLUDE LAST FILE' );
				}
				return;
			}

			$parts = explode ( '.', $lib );
			if (count ( $parts ) > 1) { // .config or .view
				$filename = $parts [1] . DS . $parts [0] . '.' . $parts [1];
			} else {
				$filename = $parts [0];
			}

			if (defined ( '_BF_FILEINCLUDED_' . strtoupper ( $filename ) ))
				return;
			$file = _BF_FRONT_LIB_DIR . DS . $filename . '.php';
			if (file_exists ( $file )) {
				if (! require ($file)) {
					echo $file;
					echo "<BR>" . bfText::_ ( 'COULD NOT INCLUDE LAST FILE' );
				}
			} else {
				$file = _BF_FRONT_LIB_DIR . DS . $filename . '.php';
				if (file_exists ( $file )) {
					if (! require ($file)) {
						echo $file;
						echo "<BR>" . bfText::_ ( 'COULD NOT INCLUDE LAST FILE' );
					}
				} else {
					echo $file;
					echo "<BR>" . bfText::_ ( 'COULD NOT INCLUDE LAST FILE' );
				}
			}
			$this->_included [] = $lib;
		}
	}

	/**
	 * PHP5 constructor does nothing.
	 *
	 */
	public function __construct() {

	}

	/**
	 * I implement the 'singleton' design pattern.
	 */
	public static function getInstance() {
		static $instance;
		if (! isset ( $instance )) {
			$c = __CLASS__;
			$instance = new $c ( );
		}
		return $instance;
	}
}

/**
 * bfImport('bfHTML');
 *
 * @param unknown_type $bfLib
 */
function bfLoad($bfLib) {
	$bfFramework = bfImport::getInstance ();
	$bfFramework->bfInclude ( $bfLib );
}

function bfImport($bflib) {
	bfLoad ( $bfLib );
}
