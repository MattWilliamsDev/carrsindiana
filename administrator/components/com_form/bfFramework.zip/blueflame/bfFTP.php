<?php
die ( 'uncomment the die in ' . __FILE__ . ' to use' );

/**
 * @version $Id: bfFTP.php 139 2010-01-03 20:45:41Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

if (! defined ( 'DS' ))
	define ( 'DS', DIRECTORY_SEPARATOR );
require (dirname ( __FILE__ ) . DS . 'libs' . DS . 'ftp' . DS . 'ftp_class.php');

class bfFTP extends ftp {

	var $loginDetailsValid = false;
	var $error = null;
	var $pathtoconfig = null;

	function bfFTP($server, $username, $password, $port = 21) {
		//			error_reporting(0);
		parent::__construct ( 0, 0 );
		if (! $this->SetServer ( $server, $port )) {
			$this->quit ();
			$this->error = ("Cannot connect to server!");
		}

		/* attempt connection */
		if (! $this->connect ()) {
			$this->error = ("Cannot connect");
		}

		/* login */
		if ($this->login ( $username, $password )) {
			$this->loginDetailsValid = true;
		}

	//		if(!$this->SetType(FTP_AUTOASCII)) echo "SetType FAILS!\n";
	//		if(!$this->Passive(FALSE)) echo "Passive FAILS!\n";


	}

	function findConfigurationFile($exact = '') {

		if ($this->loginDetailsValid === false) {
			return false;
		}
		if ($exact != '') {
			$exact = str_replace ( '/configuration.php', '', $exact );
			$this->chdir ( $exact );
			$list = $this->rawlist ( $this->pwd (), "-lA" );
			if (! $list)
				return false;
			$list = implode ( ' ', $list );
			if (preg_match ( '/configuration.php/', $list )) {
				$this->pathtoconfig = $this->pwd ();
				return true;
				//			echo '------------FOUND A CONFIG FILE in '.$this->pwd();
			} else {
				//			echo '------------NOT FOUND A CONFIG FILE';
				return false;
				$this->pathtoconfig = '';
			}
		}
		$path = ".";
		$list = $this->rawlist ( $path, "-lA" );

		if (! $list)
			return false;
		$list = implode ( ' ', $list );
		if (preg_match ( '/public_html/', $list )) {
			$this->chdir ( "public_html" );
			$this->pathtoconfig = $this->pwd ();
			//			echo '------------found a public_html dir'."\n";
		} else {
			//			echo '------------not found a public_html dir'."\n";
		}

		if (preg_match ( '/httpdocs/', $list )) {
			$this->chdir ( "httpdocs" );
			$this->pathtoconfig = $this->pwd ();
			//			echo '------------found a httpdocs dir'."\n";
		} else {
			//			echo '------------not found a httpdocs dir'."\n";
		}

		//		echo 'loacl: dev10 filder change';
		//		$this->chdir("dev10");


		$list = $this->rawlist ( $this->pwd (), "-lA" );
		$list = implode ( ' ', $list );
		if (preg_match ( '/configuration.php/', $list )) {
			$this->pathtoconfig = $this->pwd ();
			return true;
			//			echo '------------FOUND A CONFIG FILE in '.$this->pwd();
		} else {
			//			echo '------------NOT FOUND A CONFIG FILE';
			return false;
			$this->pathtoconfig = '';
		}
	}

	function getAndReadConfigurationFile($absolute_path = '') {
		if ($absolute_path == '' && $this->pathtoconfig = '') {
			$configurationFile = $this->pathtoconfig . '/configuration.php';
		} else {
			$configurationFile = $absolute_path;
		}
		$this->get ( $configurationFile, '/tmp/' . $this->_host . '.CONFIG' );
		$config = file_get_contents ( '/tmp/' . $this->_host . '.CONFIG' );
		unlink ( '/tmp/' . $this->_host . '.CONFIG' );
		return $config;
	}

	function uploadRPCFile($source, $filename) {
		$this->put ( $source, $filename );
	}

	function __destruct() {
		$this->quit ( true );
	}
}
//$test = new bfFTP('localhost','phil','d0l2ph1n');
//if ($test->loginDetailsValid===false) die(' Please check login details again !!!');
//$test->findConfigurationFile();
//$test->uploadRPCFile($source, $filename);
//$test->quit();
