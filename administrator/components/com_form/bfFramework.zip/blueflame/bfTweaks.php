<?php
/**
 * @version $Id: bfTweaks.php 119 2009-07-21 09:35:09Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or defined ( '_BFCOMBINE' ) ? '' : die ( 'Restricted access' );

/* work out which platform we are on */
if (file_exists ( dirname ( __FILE__ ) . '/../content/legacybots.php' )) {
	if (! defined ( '_BF_PLATFORM' ))
		define ( '_BF_PLATFORM', 'JOOMLA1.0' );
} else {
	if (! defined ( '_BF_PLATFORM' ))
		define ( '_BF_PLATFORM', 'JOOMLA1.5' );
}

/*
 * From Joomla 1.5.10 onwards with LEGACY Plugin enabled
 * They started poluting our space! :-) 
 */
if (isset ( $registry ))
	unset ( $registry );

/**
 * @deprecated The integrated live chat is now depreciated
 */
define ( '_BF_CHAT', false ); //default: true
define ( '_BF_CHATMONITOR', false ); //default: true


/**
 * if you find the green/red flags hard to view then change this so that they are cross/tick
 */
define ( 'bf_useflags', true ); // DEFAULT: true


/* UTF-8 Tricks */
/**
 * Trick One
 * For com_tag footer iconv issue
 */
if (_BF_PLATFORM == 'JOOMLA1.0') {
	define ( '__BF_UTF8_TRICK1', false ); //Default: false for Joomla 1.0.x true for Joomla 1.5.x
} else {
	/* Joomla 1.5.x */
	define ( '__BF_UTF8_TRICK1', true ); //Default: false for Joomla 1.0.x true for Joomla 1.5.x
}

/**
 * Trick Two
 * For com_tag footer utf8encode issue
 */
define ( '__BF_UTF8_TRICK2', false ); //Default: false


/**
 * Trick Two
 * For com_tag - Tagged click page when content items and content titles are scrambled
 */
define ( '__BF_UTF8_TRICK3', true ); //Default: true


/**
 * TURN THIS ON TO STOP BFFRAMEWORK MESSING WITH PERMISSIONS
 */
define ( '__BF_SKIP_PERMSCHECK', false ); //Default: false


/**
 * Compatibility with other charsets and older mysql versions
 *
 * Turn off utf-8 mysql set names utf-8
 * Used by bfMysql
 */
define ( '_BF_UTF8_MYSQL', true ); //default: true


/**
 * Increase memory limit - a bit of breathing space on shared hsots
 */
@ini_set ( 'memory_limit', '32M' ); //default: 32M


/**
 * Set zend compatibility mode to its default -
 * see: http://groups.google.com/group/joomla-devel/
 * browse_thread/thread/dd7ae8348dd05966/28d0ce55544fc13f?
 * #28d0ce55544fc13f
 */
@ini_set ( 'zend.ze1_compatibility_mode', '0' );

/* Skip Update Check */
define ( '_SKIP_UPDATE_CHECK', false );

/**
 * Used by bfCombine.php
 * Turn these to false to stop conflicts
 */
define ( 'bf_JSMOOTOOLS', true ); // DEFAULT: true
define ( 'bf_JSJQUERY', true ); // DEFAULT: true
define ( 'bf_useDEFLATE', true ); // DEFAULT: true
define ( 'bf_stripslashes', false ); // DEFAULT: false


/* spam and tokens */
define ( '_BF_TOKEN_MIN', 8956 );
define ( '_BF_TOKEN_MAX', 8988 );
define ( '_BF_SPAM_MIN', 86 );
define ( '_BF_SPAM_MAX', 99 );  

