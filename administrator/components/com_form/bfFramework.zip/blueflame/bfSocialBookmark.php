<?php
/**
 * @version $Id: bfSocialBookmark.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

define ( '__BF_USE_SEF_LINKS', false ); // default false


class bfSocialBookmarks {
	
	var $_link = null;
	var $_title = null;
	var $sites = array ();
	
	function __construct() {
		$this->path = _BF_FRAMEWORK_LIB_URL . '/view/images/';
		
		/* This is where you can add and remove additional social bookmark icons */
		
		$this->sites ['digg'] = array ('img' => 'digg.gif', 'link' => 'http://digg.com/submit?url=%s&title=%s' );
		$this->sites ['Delicious'] = array ('img' => 'delicious.gif', 'link' => 'http://del.icio.us/post?url=%s&title=%s&noui&jump=close&partner=phil-taylor.com&v=4' );
		$this->sites ['Furl'] = array ('img' => 'furl.gif', 'link' => 'http://furl.net/storeIt.jsp?u=%s&t=%s' );
		$this->sites ['reddit'] = array ('img' => 'reddit.gif', 'link' => 'http://reddit.com/submit?url=%s&title=%s' );
		$this->sites ['blinklist'] = array ('img' => 'blinklist.gif', 'link' => 'http://www.blinklist.com/index.php?Action=Blink/addblink.php&Description=&Url=%s&Title=%s&Tag=' );
		$this->sites ['Technorati'] = array ('img' => 'technorati2.gif', 'link' => 'http://technorati.com/cosmos/search.html?url=%s&title=%s' );
		$this->sites ['stumbleupon'] = array ('img' => 'stumbleupon.gif', 'link' => 'http://www.stumbleupon.com/submit?url=%s&title=%s' );
	
	}
	
	function setArticleDetail($link, $title) {
		if (__BF_USE_SEF_LINKS === true) {
			$this->_link = bfCompat::sefRelToAbs ( $link );
		} else {
			$this->_link = $link;
		}
		$this->_title = $title;
	}
	
	function toHTML() {
		$html = '';
		foreach ( $this->sites as $site => $sitedata ) {
			if (__BF_USE_SEF_LINKS === true) {
				$this->_link = bfCompat::sefRelToAbs ( $this->_link );
			}
			
			/* remove duplicate live site */
			$live_site = bfCompat::getLiveSite ();
			$this->_link = str_replace ( $live_site . $live_site, $live_site, $this->_link );
			
			$html .= '<a class="sociallink" title="' . $site . '" rel="nofollow" href="' . sprintf ( $sitedata ['link'], $this->_link, $this->_title ) . '"><img alt="' . $site . '" border="0" src="' . $this->path . $sitedata ['img'] . '" /></a>';
		}
		return $html;
	}
}