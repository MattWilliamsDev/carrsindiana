<?php
/**
 * @version $Id: bfCompat.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
if (! defined ( '_BF_FILEINCLUDED_BFCOMPAT' ))
	define ( '_BF_FILEINCLUDED_BFCOMPAT', true );

if (defined ( '_VALID_MOS' ) or defined ( '_JEXEC' )) {
	/* ok we are in Joomla 1.0.x or Joomla 1.5+ */
	if (! defined ( '_VALID_MOS' )) {
		/* We are in Joomla 1.5 */
		if (! defined ( '_VALID_MOS' ))
			define ( '_VALID_MOS', '1' );
		if (! defined ( '_PLUGIN_DIR_NAME' ))
			define ( '_PLUGIN_DIR_NAME', 'plugins' );
		define ( '_BF_PLATFORM', 'JOOMLA1.5' );
	} else if (! defined ( '_JEXEC' )) {
		/* we are in Joomla 1.0 */
		define ( '_JEXEC', '1' );
		if (! defined ( '_PLUGIN_DIR_NAME' ))
			define ( '_PLUGIN_DIR_NAME', 'mambots' );
		define ( '_BF_PLATFORM', 'JOOMLA1.0' );
		define ( 'JPATH_ROOT', $GLOBALS ['mosConfig_absolute_path'] );
		if (! defined ( 'DS' ))
			define ( 'DS', DIRECTORY_SEPARATOR );
	}
} else {
	header ( 'HTTP/1.1 403 Forbidden' );
	die ( 'Direct Access Not Allowed' );
}

if (! defined ( 'DS' ))
	define ( 'DS', DIRECTORY_SEPARATOR );
if (! defined ( 'JPATH_SITE' ))
	define ( 'JPATH_SITE', $GLOBALS ['mosConfig_live_site'] );
if (! defined ( '_BF_JPATH_BASE' )) {
	if (isset ( $GLOBALS ['mosConfig_absolute_path'] )) {
		/* Joomla 1.0.x */
		define ( '_BF_JPATH_BASE', $GLOBALS ['mosConfig_absolute_path'] );
	} else {
		/* Joomla 1.5 */
		define ( '_BF_JPATH_BASE', JPATH_CONFIGURATION );
	}
}

final class bfCompat {
	
	static public function isOffline() {
		if (_BF_PLATFORM == 'JOOMLA1.0') {
			return $GLOBALS ['mosConfig_offline'];
		} else {
			global $mainframe;
			return $mainframe->getCfg ( 'offline' );
		}
	}
	
	static public function getdbPrefix() {
		if (_BF_PLATFORM == 'JOOMLA1.0') {
			return $GLOBALS ['mosConfig_dbprefix'];
		} else {
			include_once (JPATH_CONFIGURATION . DS . 'configuration.php');
			$J = new JConfig ( );
			return $J->dbprefix;
		}
	}
	
	static public function getPluginDir() {
		if (_BF_PLATFORM == 'JOOMLA1.0') {
			return 'mambots';
		} else {
			return 'plugins';
		}
	}
	
	static public function getSiteName() {
		if (_BF_PLATFORM == 'JOOMLA1.0') {
			return $GLOBALS ['mosConfig_sitename'];
		} else {
			global $mainframe;
			return $mainframe->getCfg ( 'sitename' );
		}
	}
	
	static public function now() {
		return date ( 'Y-m-d H:i', time () );
	}
	
	static public function setPageTitle($str) {
		bfDocument::setTitle ( $str );
	}
	
	static public function mosConfig_live_site() {
		return bfCompat::getLiveSite ();
	}
	
	static public function getLiveSite() {
		/* for PHPUnit testing only */
		if (! defined ( '_BF_TEST_MODE' ))
			define ( '_BF_TEST_MODE', false );
		if (_BF_TEST_MODE == 1 && $_SERVER ['HTTP_HOST'] === '127.0.0.1') {
			$_SERVER ['REQUEST_URI'] = '/dev15/index.php';
			$_SERVER ['SCRIPT_NAME'] = '/dev15/index.php';
			$_SERVER ['PHP_SELF'] = '/dev15/index.php';
			/* better to test ssl cross over */
			$_SERVER ['HTTPS'] = 'on';
			
			/* and non standard port */
			$_SERVER ['SERVER_PORT'] = '443';
		}
		
		if (_BF_PLATFORM == 'JOOMLA1.5') {
			
			$str = JURI::base ();
			$str = str_replace ( '/administrator/', '', $str );
			$str = str_replace ( '/index.php', '', $str );
			if (substr ( $str, strlen ( $str ) - 1, strlen ( $str ) ) == '/') {
				$str = substr ( $str, 0, strlen ( $str ) - 1 );
			}
			return $str;
		} else {
			global $mosConfig_live_site;
			return $mosConfig_live_site;
		}
	}
	
	static public function getAbsolutePath() {
		if (_BF_PLATFORM == 'JOOMLA1.5') {
			return JPATH_SITE;
		} else {
			global $mainframe;
			return $mainframe->getCfg ( 'absolute_path' );
		}
	}
	/**
	 * Joomla 1.0 = mambots
	 * Joomla 1.5 = plugins
	 *
	 * @return unknown
	 */
	static public function mambotsfoldername() {
		
		return bfCompat::getPluginDir ();
	}
	
	static public function isAdmin($mainframe = null) {
		
		if ($mainframe === null) {
			global $mainframe;
		}
		
		return $mainframe->isAdmin ();
	
	}
	
	static public function getCfg($key) {
		if (_BF_PLATFORM == 'JOOMLA1.5') {
			switch ($key) {
				case 'absolute_path' :
					return JPATH_SITE;
					break;
				case 'live_site' :
					return str_replace ( '/administrator', '', JURI::base () );
					break;
				default :
					global $mainframe;
					return $mainframe->getCfg ( $key );
					break;
			}
		} else {
			global $mainframe;
			return $mainframe->getCfg ( $key );
		}
	}
	
	static public function redirect($location, $message) {
		global $mainframe;
		$mainframe->redirect ( $location, $message );
	}
	
	static public function getUser($client = '') {
		global $mainframe;
		if (bfCompat::isAdmin () or $client == 'admin') {
			global $my;
		} else {
			$my = $mainframe->getUser ();
		}
		return $my;
	}
	
	static public function getMainFrame($database, $option, $task, $client = 'front') {
		global $mainframe;
		return $mainframe;
	}
	
	static public function getLangDir() {
		return 'ltr'; // or 'rtr'
	}
	
	static public function getLangSite() {
		global $mainframe;
		if (_BF_PLATFORM == 'JOOMLA1.5') {
			$mainframe->getCfg ( 'lang_site' );
		} else {
			$mainframe->getCfg ( 'lang_site' );
		}
	}
	
	static public function getDBO() {
		if (_BF_PLATFORM == 'JOOMLA1.5') {
			$db = JFactory::getDBO ();
			return $db;
		} else {
			global $mainframe;
			if (! @$GLOBALS ['mosConfig_host']) {
				include (bfCompat::getAbsolutePath () . DS . 'configuration.php');
				$db = bfDatabase::getInstance ( 'mysql', $mosConfig_host, $mosConfig_user, $mosConfig_password, $mosConfig_db, $mosConfig_dbprefix );
			
			} else {
				$db = bfDatabase::getInstance ( 'mysql', $GLOBALS ['mosConfig_host'], $GLOBALS ['mosConfig_user'], $GLOBALS ['mosConfig_password'], $GLOBALS ['mosConfig_db'], $GLOBALS ['mosConfig_dbprefix'] );
			}
			return $db;
		}
	}
	
	static public function findOption() {
		global $mainframe;
		return $mainframe->get ( 'component' );
	}
	
	static public function findItemid() {
		$Itemid = '';
		
		if (_BF_PLATFORM != 'JOOMLA1.5') {
			$Itemid = 1;
		}
		
		return $Itemid;
	}
	
	static public function sefRelToAbs($str) {
		
		if (_BF_PLATFORM == 'JOOMLA1.5') {
			/* function doesnt exist in admin!!! */
			// Replace all &amp; with & as the router doesn't understand &amp;
			$url = str_replace ( '&amp;', '&', $str );
			
			$uri = JURI::getInstance ();
			$prefix = $uri->toString ( array ('scheme', 'host', 'port' ) );
			return $prefix . JRoute::_ ( $url );
		} else {
			/* function doesnt exist in admin!!! */
			if (function_exists ( 'sefRelToAbs' )) {
				$str = sefRelToAbs ( $str );
			}
			return $str;
		}
	}
	
	static public function setMeta($type, $data) {
		if (_BF_PLATFORM == 'JOOMLA1.5') {
			$doc = JFactory::getDocument ();
			$doc->setMetaData ( $type, $data );
		} else {
			global $mainframe;
			$mainframe->addMetaTag ( $type, $data );
		}
	}
	
	static public function getItemID($id) {
		
		bfLoad ( 'bfCache' );
		$cache = bfCache::getInstance ();
		
		$key = 'ITEMID_FOR_' . $id;
		
		$cached = $cache->get ( md5 ( $key ), 'sql' );
		if ($cached) {
			return $cached;
		} else {
			global $mainframe;
			$itemid = $mainframe->getItemid ( $id );
			$cache->api_add ( md5 ( $key ), $itemid, 'sql' );
			$cache->save ();
			return $itemid;
		}
	}
	
	static public function getComponentItemID() {
		global $mainframe;
		$registry = bfRegistry::getInstance ( $mainframe->get ( 'component' ) );
		return $registry->getValue ( 'config.itemid', '1' );
	}
	
	/* for mosFormatDate */
	static public function bfFormatDate($date = 'now', $format = null, $offset = null) {
		
		if (function_exists ( 'mosFormatDate' )) {
			return mosFormatDate ( $date, $format, $offset );
		} else {
			if (! $format) {
				$format = JText::_ ( 'DATE_FORMAT_LC1' );
			}
			
			return JHTML::_ ( 'date', $date, $format, $offset );
		}
	}
	
	static public function getToken($forceNew = false) {
		if (_BF_PLATFORM == 'JOOMLA1.5') {
			
			$user = JFactory::getUser ();
			$session = JFactory::getSession ();
			$conf = new JConfig ( );
			return md5 ( $conf->secret . $user->get ( 'id', 0 ) . $session->getToken ( $forceNew ) );
			
		} else {
			return josSpoofValue ( $forceNew );
		}
	}
	
	static public function addCSS($string) {
		if (_BF_PLATFORM == 'JOOMLA1.5') {
			/* @var $doc JDocument */
			$doc = & JFactory::getDocument ();
			$doc->addStyleSheet ( $string );
		} else {
			global $mainframe;
			$str = '<style type="text/css" media="all">@import url(' . $string . ');</style>';
			$mainframe->addCustomHeadTag ( $str );
		}
	}
	
	static public function getSecret() {
		if (_BF_PLATFORM == 'JOOMLA1.5') {
			$config = new JConfig ( );
			return $config->secret;
		} else {
			global $mainframe;
			return $mainframe->getCfg ( 'secret' );
		}
	}
}