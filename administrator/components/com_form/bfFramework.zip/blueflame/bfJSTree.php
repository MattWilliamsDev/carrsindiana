<?php
/**
 * @version $Id: bfJSTree.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );


/* utility class to help create javascript for dTree
 * http://www.destroydrop.com/javascripts/tree/example/
 */
final class bfJSTree {

	public $autonum = 0;

	public $_js = 'var Tree = new Array;';

	public $_jsfile = null;

	public function __construct() {
		$this->_jsfile = '/system/blueflame/libs/treeview/treeview.js';
	}

	public function makejssafe($str) {
		$str = str_replace ( ' ', '', $str );
		$str = str_replace ( '?', '', $str );
		$str = str_replace ( '-', '', $str );
		return $str;
	}

	public function addJStoHEAD() {
		if (@_POPUP === 1) {
			if (_BF_PLATFORM == 'JOOMLA1.0') {
				global $mainframe;
				$ls = bfCompat::getLiveSite ();
				$mf = bfCompat::mambotsfoldername ();
				echo (sprintf ( '<script src="%s" type="text/javascript"></script>', $ls . '/' . $mf . $this->_jsfile ));

				$mainframe->addCustomHeadTag ( $this->_getJS () );
			} else {
				global $mainframe;
				$ls = bfCompat::getLiveSite ();
				$mf = bfCompat::mambotsfoldername ();
				echo (sprintf ( '<script src="%s" type="text/javascript"></script>', $ls . '/' . $mf . $this->_jsfile ));

				$mainframe->addCustomHeadTag ( $this->_getJS () );
			}
		} else {
			if (_BF_PLATFORM == 'JOOMLA1.0') {
				global $mainframe;
				$ls = bfCompat::getLiveSite ();
				$mf = bfCompat::mambotsfoldername ();
				$mainframe->addCustomHeadTag ( sprintf ( '<script src="%s" type="text/javascript"></script>', $ls . '/' . $mf . $this->_jsfile ) );

				$mainframe->addCustomHeadTag ( $this->_getJS () );
			} else {
				global $mainframe;
				$ls = bfCompat::getLiveSite ();
				$mf = bfCompat::mambotsfoldername ();
				$mainframe->addCustomHeadTag ( sprintf ( '<script src="%s" type="text/javascript"></script>', $ls . '/' . $mf . $this->_jsfile ) );

				$mainframe->addCustomHeadTag ( $this->_getJS () );
			}
		}
	}

	public function _append($catid, $parentid, $catname, $link) {
		$this->_js .= "Tree[$this->autonum] = \"" . $catid . '|' . $parentid . '|' . $catname . '|' . $link . '";';
		$this->autonum = $this->autonum + 1;
	}

	public function _getJS() {
		return sprintf ( '<script type="text/javascript">%s</script>', $this->_js );
	}
}