<?php
function smarty_block_sefRelToAbs($params, $content, &$smarty, &$repeat){
	if (isset($content)) {
		return bfCompat::sefRelToAbs($content);
//		if (function_exists('sefRelToAbs')){
//			return sefRelToAbs($content);
//		}
	}
}
?>
