<?php
/**
 * @version $Id: entry.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */

/* Set flag that this is a parent file */
define( '_VALID_MOS', 1 );

/**
 * If you get "You must login" popups then please enable this
 * To enable this line remove the // infront of the session_module_name("files");
 **/
// session_module_name("files");

require( '../../../../globals.php' );
require( '../../../../configuration.php' );
require( '../../../../includes/joomla.php' );

/* load system bot group */
$_MAMBOTS->loadBotGroup( 'system' );

/* Compatibility with JPromoter */
if (@isset($_SESSION)  && @isset($_SESSION['REQ_URI'])){
	unset($_SESSION['REQ_URI']);
	unset($_SESSION);
}

// must start the session before we create the mainframe object
//session_name( md5( $mosConfig_live_site ) );
session_start();

/* mainframe is an API workhorse, lots of 'core' interaction routines */
$mainframe 	= new mosMainFrame( $database, 'com_xajax', '../../../../' );
$my	    	= $mainframe->initSession();

/* trigger the onStart events - Needed for JoomFish*/
$_MAMBOTS->trigger( 'onStart' );

/* trigger the onAfterStart events */
$_MAMBOTS->trigger( 'onAfterStart' );
?>