<?php
/**
 * @version $Id: bfDefine.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

if (@! defined ( '_BF_DEFINES_INCLUDED' )) {
	
	define ( '_BF_JPATH_SITE', bfCompat::getLiveSite () );
	
	/**
	 * Generic Paths to Blue Flame Framework
	 */
	define ( '_BF_FRAMEWORK_LIB_DIR', bfCompat::getCfg ( 'absolute_path' ) . DS . _PLUGIN_DIR_NAME . DS . 'system' . DS . 'blueflame' );
	define ( '_BF_FRAMEWORK_LIB_URL', bfCompat::getCfg ( 'live_site' ) . '/' . _PLUGIN_DIR_NAME . '/system/blueflame' );
	define ( '_BF_FRONT_LIB_DIR', _BF_FRAMEWORK_LIB_DIR );
	define ( '_BF_FRONT_LIB_VIEW_DIR', _BF_FRONT_LIB_DIR . DS . 'view' );
	define ( '_BF_SMARTY_LIB_DIR', _BF_FRAMEWORK_LIB_DIR . DS . 'libs' . DS . 'smarty' );
	define ( '_BF_FRAMEWORK_LANGUAGE_DIR', _BF_FRAMEWORK_LIB_DIR . DS . 'language' );
	
	define ( '_BF_CACHE_DIR', _BF_FRAMEWORK_LIB_DIR . DS . 'cache' );
	
	/* Make sure we only define things once :-) */
	define ( '_BF_DEFINES_INCLUDED', '1' );
}