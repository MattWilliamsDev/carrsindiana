<?php
/**
 * @version $Id: bfUser.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

final class bfUser {
	
	public $_my = null;
	
	public static function getInstance($user_id = null) {
		$user = new bfUser ( );
		$my = new stdClass ( );
		if ($user_id === null) {
			
			$isAdmin = bfCompat::isAdmin ();
			
			/** @todo Sort this mess out!!! */
			if (_BF_PLATFORM == 'JOOMLA1.5') {
				$my = & JFactory::getUser ();
			} elseif ($isAdmin) {
				
				$my->id = intval ( bfRequest::getSessionVar ( 'session_user_id', 0, 'SESSION' ) );
				$my->username = strval ( bfRequest::getSessionVar ( 'session_username', '', 'SESSION' ) );
				$my->usertype = strval ( bfRequest::getSessionVar ( 'session_usertype', '', 'SESSION' ) );
				$my->gid = intval ( bfRequest::getSessionVar ( 'session_gid', '0', 'SESSION' ) );
				$my->params = bfRequest::getSessionVar ( 'session_user_params', '', 'SESSION' );
			} elseif (! $isAdmin) {
				if (_BF_PLATFORM == 'JOOMLA1.5') {
					$my = & JFactory::getUser ();
				} else {
					global $mainframe;
					$my = $mainframe->getUser ();
				}
			}
		
		} elseif ($user_id == 0) {
			$my->id = 0;
			$my->username = '';
			$my->usertype = '';
			$my->gid = '0';
			$my->params = '';
		} else {
			$db = bfCompat::getDBO ();
			$db->setQuery ( 'SELECT * FROM #__users WHERE id = "' . ( int ) $user_id . '"' );
			$rows = $db->LoadObjectList ();
			$row = $rows [0];
			foreach ( $row as $k => $v ) {
				$my->$k = $v;
			}
		}
		$user->_my = $my;
		return $user;
	}
	
	public function get($key) {
		
		if (is_array ( $this->_my )) {
			return $this->_my [$key];
		} else {
			return @$this->_my->$key;
		}
	}
	
	public function set($key, $value) {
		$this->_my->$key = $value;
	}
}