<?php
/**
 * @version $Id: bfLog.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

class bfLog {
	
	/**
	 * @var string The logfiles path and filename
	 */
	var $_logFile;
	/**
	 * @var bool Toggle logging
	 */
	var $_controller_log = "off";
	
	/**
	 * Enter description here...
	 *
	 * @var unknown_type
	 */
	var $_addTimeStamp = true;
	
	/**
	 * I store the reegistry
	 *
	 * @var object bfRegistry
	 */
	var $_registry = null;
	
	/**
	 * Enter description here...
	 *
	 */
	function __construct($component) {
	}
	
	/**
	 * Enter description here...
	 *
	 * @return bfLog
	 */
	function bfLog($component) {
		$this->__construct ( $component );
		$this->_component = $component;
		/* Set up our registry and namespace */
		$this->_registry = & bfRegistry::getInstance ( $component, $component );
		$this->_logFile = $this->_registry->getValue ( 'config.devLogFile' );
	}
	
	/**
	 * This implements the 'singleton' design pattern.
	 */
	function &getInstance($component = 'framework') {
		static $instance;
		if (! isset ( $instance )) {
			$c = __CLASS__;
			$instance = new $c ( $component );
		}
		$instance->_registry = & bfRegistry::getInstance ( $component, $component );
		$instance->_logFile = $instance->_registry->getValue ( 'config.devLogFile', '/dev/null' );
		return $instance;
	}
	
	/**
	 * Turn logging on if I can touch the logfile
	 *
	 */
	function setLogOn() {
		$this->getLogFileFromConfig ();
		if (@touch ( $this->_logFile ))
			$this->_controller_log = "on";
	}
	
	/**
	 * Turn logging off
	 *
	 */
	function setLogOff() {
		$this->_controller_log = "off";
	}
	
	/**
	 * Enter description here...
	 *
	 */
	function getLogFileFromConfig() {
		$this->_logFile = $this->_registry->getValue ( 'config.devLogFile' );
	}
	
	/**
	 * Append $msg with a timestamp to the end of the log file.
	 *
	 * @param unknown_type $msg
	 */
	function log($msg) {
		if (! $this->_logFile) {
			$this->_logFile = $this->_registry->getValue ( 'config.devLogFile' );
		}
		$this->checkLogFile ( $msg );
		if ($this->_controller_log == 'on') {
			if (! is_string ( $msg )) {
				$this->logObject ( $msg );
			} else {
				$timestamp = $this->getTimeStamp ();
				$flog = fopen ( $this->_logFile, "a" );
				fwrite ( $flog, $timestamp . "$msg \n" );
				fclose ( $flog );
			}
		}
	}
	
	/**
	 * give log some balnk new lines
	 *
	 * @param int $num
	 */
	function spacer($num) {
		if ($this->_controller_log == 'on') {
			while ( $num > 0 ) {
				$flog = fopen ( $this->_logFile, "a" );
				fwrite ( $flog, "\n" );
				fclose ( $flog );
				$num --;
			}
		}
	}
	
	/**
	 * Append an object to the end of the log file.
	 *
	 * @param object $arr
	 */
	function logObject($arr) {
		ob_start ();
		
		print_R ( $arr );
		
		$CONTENTS = ob_get_contents ();
		ob_end_clean ();
		$this->log ( 'OBJECT: ' . $CONTENTS );
	
	}
	
	/**
	 * Add a timestamp to log entries.
	 *
	 * @return unknown
	 */
	function getTimeStamp() {
		if ($this->_addTimeStamp == true) {
			return date ( 'Y-m-d H:i:s', time () ) . ': ';
		}
	}
	
	/**
	 * Dump contents of log file to the screen
	 *
	 */
	function dumpToScreen() {
		echo '<pre>' . file_get_contents ( $this->_logFile ) . '</pre>';
	}
	
	/**
	 *
	 * I ensure that the log file is writable and switch off logging
	 * if it is not.
	 *
	 * @param unknown_type $msg
	 */
	function checkLogFile($msg = null) {
		if (@! is_writeable ( $this->_logFile )) {
			$this->setLogOff ();
			//	bfError::raiseWarning('404','Could not write to log file...' .  $msg . '<br />');
		}
	}
	
	/**
	 *
	 * I truncate the log file (to 0 bytes by default).
	 *
	 * @param unknown_type $msg
	 */
	function truncate($size = 0) {
		$this->checkLogFile ();
		if ($this->_controller_log == 'on') {
			$flog = fopen ( $this->_logFile, 'a' );
			ftruncate ( $flog, $size );
			fclose ( $flog );
		}
	}

}

function bfLogger(&$controller, $who, $what, $where, $why, $note) {
	$l = $controller->getModel ( 'logger' );
	$l->who = $who;
	$l->what = $what;
	$l->where = $where;
	$l->why = $why;
	$l->note = $note;
	$l->ip = $_SERVER ['REMOTE_ADDR'];
	$l->store ();
}