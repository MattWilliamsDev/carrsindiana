<?php
/**
 * @version $Id: bfSmarty.php 148 2010-01-24 01:15:50Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

define ( '_BF_BRANDING', 1 );

require_once (_BF_FRAMEWORK_LIB_DIR . DS . 'libs' . DS . 'smarty' . DS . 'Smarty.class.php');
bfLoad ( 'bfUTF8' );

class bfSmarty extends Smarty {
	
	var $_component = '';
	
	function __construct($component) {
		$this->_component = $component;
		parent::smarty ();
		$this->_configurePaths ();
		$this->_loadLangFile ();
	
	}
	
	/**
	 * I implmenet static class
	 *
	 * @return unknown
	 */
	function getInstance($component = null) {
		global $mainframe;
		if ($component === null) {
			$component = $mainframe->get ( 'component' );
		}
		static $instance;
		
		if (! isset ( $instances )) {
			$instances = array ();
		}
		
		if (empty ( $instances [$component] )) {
			$c = __CLASS__;
			$instances [$component] = new $c ( $component );
			$instances [$component]->_component = $component;
		}
		//		echo $instances[$component]->compile_dir;
		return $instances [$component];
	}
	
	function _configurePaths() {
		global $mainframe;
		@chmod ( _BF_SMARTY_LIB_DIR, 0777 );
		$this->_setTemplatePath ();
		$this->templates_c = _BF_SMARTY_LIB_DIR . DS . 'templates_c';
		@chmod ( $this->templates_c, 0777 );
		$this->compile_dir = _BF_SMARTY_LIB_DIR . DS . 'templates_c' . DS . $this->_component;
		@chmod ( $this->compile_dir, 0777 );
		$this->cache_dir = _BF_SMARTY_LIB_DIR . DS . 'cache';
		@chmod ( $this->cache_dir, 0777 );
		$this->config_dir = _BF_SMARTY_LIB_DIR . DS . 'configs';
		$this->_checkPathsExist ();
	}
	
	function _checkPathsExist() {
		$this->_check_dir ( $this->compile_dir );
		$this->_check_dir ( $this->cache_dir );
	}
	
	function _check_dir($dirpath) {
		$make_dir = '';
		foreach ( preg_split ( '~/~', $dirpath ) as $subdir ) {
			$make_dir .= "$subdir/";
			
			/* dont create anything higher than the absolute path to joomla */
			$root = bfCompat::getAbsolutePath ();
			if (! preg_match ( '~'.addslashes($root . DS . bfCompat::mambotsfoldername () . DS) . 'system'.'~i', $make_dir )) {
				continue;
			}
			
			/* create folder if not exists */
			if (! file_exists ( $make_dir )) {
				if (@! mkdir ( $make_dir )) {
					die ( bfText::_ ( 'Could not create smarty template cache folder' ) . ' : ' . $make_dir );
				} else {
					chmod ( $make_dir, 0755 );
					if (! file_exists ( $make_dir . "index.php" ) && file_exists ( $make_dir )) {
						@touch ( $dirpath . DS . "index.php" );
						@chmod ( $dirpath . DS . "index.php", 0655 );
					}
				}
			}
		}
	}
	
	function cache($level = 0) {
		$this->caching = $level;
	}
	
	function _setTemplatePath($path = null) {
		if ($path === null) {
			global $mainframe;
			$this->template_dir = bfCompat::getCfg ( 'absolute_path' ) . DS . 'components' . DS . $this->_component . DS . 'view' . DS . (bfCompat::isAdmin () ? 'admin' : 'front') . DS . 'templates';
		} else {
			$this->template_dir = $path;
		}
	}
	
	function assign($k, $v) {
		$utf = new bfUtf8 ( );
		parent::assign ( $k, $utf->utf8ToHtmlEntities ( $v ) );
	}
	
	function assignFromArray($arr) {
		
		$utf = new bfUtf8 ( );
		foreach ( $arr as $k => $v ) {
			if ($k == '_registry')
				continue;
			if ($k == 'LOG')
				continue;
			$this->assign ( strtoupper ( $k ), $utf->utf8ToHtmlEntities ( $v ) );
		}
	}
	
	function arrayFromArrayOfObjects($arr) {
		$utf = new bfUtf8 ( );
		$newArr = array ();
		foreach ( $arr as $obj ) {
			$r = array ();
			foreach ( $obj as $k => $v ) {
				if ($k == '_registry')
					continue;
				if ($k == 'LOG')
					continue;
				$r [$k] = $utf->utf8ToHtmlEntities ( $v );
			}
			$newArr [] = $r;
		}
		//		echo "<pre>";
		//		print_R($newArr);
		//		echo "</pre>";
		return $newArr;
	}
	
	function _loadLangFile() {
		$arr = array ();
		$this->assignFromArray ( $arr );
	}
	
	function _setDefaultGlobals() {
		if (_BF_BRANDING === 1) {
			$this->assign ( '_BF_BRANDING', 1 );
		}
		$this->assign ( 'LIVE_SITE', bfCompat::getLiveSite () );
		$this->assign ( 'LIVESITE', bfCompat::getLiveSite () );
		$this->assign ( 'ABSOULTE_PATH', bfCompat::getAbsolutePath () );
		$this->assign ( 'ABSOLUTE_PATH', bfCompat::getAbsolutePath () );
		$this->assign ( 'PLUGIN_DIR', bfCompat::getPluginDir () );
		$this->assign ( 'PLUGINS_DIR', bfCompat::getPluginDir () );
		$this->assign ( 'LIB_IMG_URL', bfCompat::getLiveSite () . '/' . bfCompat::getPluginDir () . '/system/blueflame/view/images/' );
		$this->assign ( 'TAGCLOUD_LINK', bfCompat::sefRelToAbs ( 'index.php?option=com_tag&tag=cloud' ) );
		$this->assign ( 'TAGCLOUD', bfCompat::sefRelToAbs ( 'index.php?option=com_tag&tag=cloud' ) );
		$this->assign ( 'BLUEFLAMESITE', 'http://www.blueflameit.ltd.uk' );
		if (_BF_PLATFORM == 'JOOMLA1.0') {
			global $mainframe;
			$this->assign ( 'LIVETEMPLATE', $mainframe->getTemplate () );
		}
	
	}
	
	function display($tmpl_name, $useUserTemplate = false, $usertemplate_id = null, $cache_id = null) {
		$this->_setDefaultGlobals ();
		
		if ($useUserTemplate === true) {
			$this->_setTemplatePathToUserDir ();
		} else {
			if (! file_exists ( $this->template_dir . DS . $tmpl_name )) {
				$this->_setTemplatePathToFramework ();
			}
		}
		
		if (preg_match ( '~/~', $tmpl_name )) {
			$filename = basename ( $tmpl_name );
			$path = str_replace ( $filename, '', $tmpl_name );
			$this->template_dir = $path;
		}
		
		parent::display ( $tmpl_name, $cache_id );
	}
	
	function render($tmpl_name, $useUserTemplate = false, $compile_id = null, $cache_id = null) {
		$this->_setDefaultGlobals ();
		
		if ($useUserTemplate === true) {
			$this->_setTemplatePathToUserDir ();
		} else {
			if (! file_exists ( $this->template_dir . DS . $tmpl_name )) {
				$this->_setTemplatePathToFramework ();
			}
		}
		return parent::fetch ( $tmpl_name, $cache_id, $compile_id );
	}
	
	function _setTemplatePathToUserDir() {
		global $mainframe;
		$this->template_dir = bfCompat::getCfg ( 'absolute_path' ) . DS . 'components' . DS . $this->_component . DS . 'view' . DS . 'user_templates';
	}
	
	function _setTemplatePathToFramework() {
		$this->template_dir = bfCompat::getCfg ( 'absolute_path' ) . DS . _PLUGIN_DIR_NAME . DS . 'system' . DS . 'blueflame' . DS . 'view' . DS . 'templates';
	}
	
	function getLayouts($fieldname, $selected = 0, $pertainsto = null) {
		global $mainframe;
		$db = & bfCompat::getDBO ();
		
		if ($pertainsto !== null) {
			$where = ' WHERE appliesto =\'' . $pertainsto . '\'';
		} else {
			$where = '';
		}
		
		$mysql_table = '#__' . $mainframe->get ( 'component_shortname' ) . '_layouts';
		
		/* get the layouts */
		$db->setQuery ( 'SELECT id as value, title as `text` FROM ' . $mysql_table . $where . ' ORDER BY title ASC' );
		$layouts = $db->LoadObjectList ();
		
		$temp = array ();
		$temp [] = bfHTML::makeOption ( '0', '--' . bfText::_ ( 'not set' ) . '--' );
		
		foreach ( $layouts as $layout ) {
			$temp [] = bfHTML::makeOption ( $layout->value, $layout->text );
		}
		
		/* create an html select list */
		$html = bfHTML::selectList2 ( $temp, $fieldname, ' class="flatinputbox"', 'value', 'text', $selected );
		
		/* return it */
		return $html;
	}
	
	function getPertainsto($selected) {
		global $mainframe;
		$registry = & bfRegistry::getInstance ( $mainframe->get ( 'component' ) );
		
		$pertainsto = $registry->getValue ( 'bfFramework_' . $mainframe->get ( 'component_shortname' ) . '.layout.pertainsto' );
		
		$temp = array ();
		$temp [] = bfHTML::makeOption ( '', '-- Not Set --' );
		
		if (! is_array ( $pertainsto )) {
			//echo 'bfFramework_'.$mainframe->get('component_shortname').'.layout.pertainsto '.bfText::_('NOT SET IN REGISTRY');
		} else {
			foreach ( $pertainsto as $layout ) {
				$temp [] = bfHTML::makeOption ( $layout, ucwords ( $layout ) );
			}
		}
		/* create an html select list */
		$html = bfHTML::selectList2 ( $temp, 'appliesto', ' class="flatinputbox"', 'value', 'text', $selected );
		
		/* return it */
		return $html;
	}
}