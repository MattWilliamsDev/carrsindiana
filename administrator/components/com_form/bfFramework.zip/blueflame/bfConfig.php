<?php
/**
 * @version $Id: bfConfig.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

class bfConfig {
	
	/**
	 * The configuration file name
	 *
	 * @var unknown_type
	 */
	var $_configfileName = '';
	/**
	 * The configuration file name with its path
	 *
	 * @var unknown_type
	 */
	var $_configfileWithPath = '';
	/**
	 * I flag whether the configuration file is writable
	 *
	 * @var boolean
	 */
	var $_isWriteable = false;
	
	/**
	 * The current configuration
	 *
	 * @var array
	 */
	var $_currentConfig = array ();
	
	/**
	 * The constructor
	 */
	function __construct($option) {
		$this->_component = $option;
		$registry = bfRegistry::getInstance ( $option, $option );
		
		$this->setConfigFileName ();
		$this->isWriteable ();
		$this->loadConfigFromINIFile ();
	}
	
	/**
	 * This implements the 'singleton' design pattern.
	 */
	function getInstance($option = '') {
		static $instance;
		
		if (! isset ( $instances )) {
			$instances = array ();
		}
		
		if (! isset ( $instances [$option] )) {
			$c = __CLASS__;
			$instances [$option] = new $c ( $option );
			$instances [$option]->_component = $option;
		}
		
		return $instances [$option];
	}
	
	/**
	 * test if config file is writable
	 * 
	 * @return bool
	 */
	function isWriteable() {
		if (is_writeable ( $this->_configfileWithPath )) {
			$this->_isWriteable = 1;
		} else {
			$this->_isWriteable = 0;
		}
		return $this->_isWriteable;
	}
	
	/**
	 * Set the config file name
	 */
	function setConfigFileName($filename = null) {
		if ($filename) {
			$this->_configfileName = $filename;
		} else {
			$name = str_replace ( 'com_', '', $this->_component );
			
			if ($name == 'framework') {
				$filename = $name . 'local';
			} else {
				$filename = $name;
			}
			$this->_configfileName = $filename . '.config.php';
		}
		$this->setConfigFileWithPath ();
	}
	
	/**
	 * Set the config file Path
	 */
	function setConfigFileWithPath($path = null) {
		if ($path) {
			$this->_configfileWithPath = $path;
		} else {
			if (file_exists ( bfCompat::getAbsolutePath () . DS . 'components' . DS . $this->_component . DS . 'etc' . DS . $this->_configfileName )) {
				$this->_configfileWithPath = bfCompat::getAbsolutePath () . DS . 'components' . DS . $this->_component . DS . 'etc' . DS . $this->_configfileName;
			} else {
				die ( 'Could not locate a configuration file!, I looked at: ' . bfCompat::getAbsolutePath () . DS . 'components' . DS . $this->_component . DS . 'etc' . DS . $this->_configfileName );
			}
		}
	}
	
	/**
	 * Load configuration from config file.
	 *
	 * @return bool
	 */
	function loadConfigFromINIFile() {
		if (! $this->_configfileWithPath || ! file_exists ( $this->_configfileWithPath )) {
			return false;
		}
		/* Set up our registry and namespace */
		$registry = bfRegistry::getInstance ( $this->_component, $this->_component );
		$registry->loadFile ( $this->_configfileWithPath, 'ini', 'config' );
		
		/* Fudge as there is a bug in bfRegistry and loadFile */
		$r = $registry->_registry ['config'] ['data']; //object
		unset ( $registry->_registry ['config'] );
		
		/* fudge: Convert from object to array */
		foreach ( $r as $k => $v ) {
			$registry->setValue ( 'config.' . $k, $v );
			$this->$k = $v;
		}
		return true;
	}
	
	/**
	 * Reload the configuration from the .ini file
	 *
	 */
	function reload() {
		$this->loadConfigFromINIFile ();
	}
	
	/**
	 * Save (write back) the config file
	 *
	 * @param unknown_type $args
	 * @return bool
	 */
	function saveConfigFile($args) {
		global $mainframe;
		$registry = bfRegistry::getInstance ( $mainframe->get ( 'component' ), $mainframe->get ( 'component' ) );
		$user = bfUser::getInstance ();
		$now = date ( 'Y-m-d H:i:s', time () );
		$class = 'bfConfig' . $mainframe->get ( 'component_shortname' );
		
		/* Set our config defaults to the new values */
		
		$configVars = $registry->getValue ( 'bfFramework_' . $mainframe->get ( 'component_shortname' ) . '.config_vars' );
		$saveThis = array ();
		foreach ( $args as $key => $value ) {
			if (key_exists ( $key, $configVars )) {
				$saveThis [$key] = $value;
			}
		}
		
		$txt = "<?php \n";
		$txt .= "defined( '_JEXEC' ) or die( 'Restricted access' );\n";
		$txt .= "/* Last Changed: " . $now . " */ \n";
		$txt .= "/* Changed By: " . $user->get ( 'id' ) . '::' . $user->get ( 'username' ) . " */ \n\n";
		$txt .= "?>\n";
		$txt .= "[" . $this->_component . "]\n";
		
		foreach ( $saveThis as $k => $v ) {
			if (substr ( $k, 0, 1 ) != '_') {
				$txt .= $k . "=" . addslashes ( $v ) . "\n";
			}
		}
		
		if ($fp = fopen ( $this->_configfileWithPath, "w" )) {
			fputs ( $fp, $txt, strlen ( $txt ) );
			fclose ( $fp );
			return true;
		} else {
			return false;
		}
	}
}