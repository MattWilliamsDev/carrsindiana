<?php
/**
 * @version $Id: index.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
header("HTTP/1.0 404 Not Found");
?>
<html>
<title>404 - Page Not Found.</title>
<style type="text/css">div#error{align:center;text-align:center;border:2px double red;width:770px;margin:0 auto;padding:50px;}#bfCopyright{border-top:1px solid #CCC;clear:both;display:block;margin-top:50px;padding-top:20px;text-align:center;color:#333;font-family:Arial,Helvetica,sans-serif;font-size:12px;}</style>
<body>
<div id="error">
	<h1>Page Not Found</h1>
		<p>For More Joomla Components Please Visit Our Site At:
		<br />
		<a rel="index" href="http://www.phil-taylor.com/" title="Joomla Components">Joomla Extensions</a></p>
</div>

<div id="bfCopyright">
	<b>
		<i>Power In Simplicity!</i>
	</b>
	<br />
	&copy; <?php echo date('Y'); ?> <a target="_blank" href="http://www.phil-taylor.com/" title="Joomla Extensions" class="hasTip">Blue Flame IT Ltd.</a>
	<br />
</div>
</body>
</html>