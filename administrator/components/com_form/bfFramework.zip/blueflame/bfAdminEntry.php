<?php
/**
 * @version $Id: bfAdminEntry.php 146 2010-01-11 11:31:23Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */

if (defined ( '_VALID_MOS' ) or defined ( '_JEXEC' )) {
	/* ok we are in Joomla 1.0.x or Joomla 1.5+ */
	if (! defined ( '_VALID_MOS' )) {
		/* We are in Joomla 1.5 */
		if (! defined ( '_VALID_MOS' ))
			define ( '_VALID_MOS', '1' );
		if (! defined ( '_PLUGIN_DIR_NAME' ))
			define ( '_PLUGIN_DIR_NAME', 'plugins' );
		if (! defined ( '_BF_PLATFORM' ))
			define ( '_BF_PLATFORM', 'JOOMLA1.5' );
		if (! defined ( '_BF_JPATH_BASE' ))
			define ( '_BF_JPATH_BASE', JPATH_CONFIGURATION );
	} else if (! defined ( '_JEXEC' )) {
		/* we are in Joomla 1.0 */
		define ( '_JEXEC', '1' );
		if (! defined ( '_PLUGIN_DIR_NAME' ))
			define ( '_PLUGIN_DIR_NAME', 'mambots' );
		define ( '_BF_PLATFORM', 'JOOMLA1.0' );
		define ( 'JPATH_ROOT', $GLOBALS ['mosConfig_absolute_path'] );
		define ( '_BF_JPATH_BASE', $GLOBALS ['mosConfig_absolute_path'] );
		if (! defined ( 'DS' ))
			define ( 'DS', DIRECTORY_SEPARATOR );
	} else {
		if (defined ( '_VALID_MOS' ) or defined ( '_JEXEC' )) {
			/* Joomla 1.5 with legacy mode enabled*/
			/* We are in Joomla 1.5 */
			if (! defined ( '_VALID_MOS' ))
				define ( '_VALID_MOS', '1' );
			if (! defined ( '_PLUGIN_DIR_NAME' ))
				define ( '_PLUGIN_DIR_NAME', 'plugins' );
			if (! defined ( '_BF_PLATFORM' ))
				define ( '_BF_PLATFORM', 'JOOMLA1.5' );
		} else {
			die ( 'Unknown Platform- Contact Support' );
		}
	}
	if (! defined ( 'JPATH_SITE' ))
		define ( 'JPATH_SITE', $GLOBALS ['mosConfig_absolute_path'] );
	if (! defined ( 'DS' ))
		define ( 'DS', DIRECTORY_SEPARATOR );
	if (! defined ( '_JEXEC' ))
		define ( '_JEXEC', '1' );
	if (! defined ( 'BF_PLATFORM' ))
		define ( 'BF_PLATFORM', 'STANDALONE' );
	if (! defined ( 'JPATH_BASE' ))
		define ( 'JPATH_BASE', $GLOBALS ['mosConfig_absolute_path'] );

} else {
	header ( 'HTTP/1.1 403 Forbidden' );
	die ( 'Direct access not allowed' );
}

//error_reporting(E_ALL);


/* Pull in the bfFramework */
require_once (JPATH_ROOT . DS . _PLUGIN_DIR_NAME . DS . 'system' . DS . 'blueflame' . DS . 'bfCompat.php');
require_once (JPATH_ROOT . DS . _PLUGIN_DIR_NAME . DS . 'system' . DS . 'blueflame' . DS . 'bfFramework.php');

/* Initialise the session before calling the controller constructor */
$bfsession = bfSession::getInstance ( $mainframe->get ( 'component' ) );
/* @var $bfsession bfSession */

/* Grab our registry */
$registry = bfRegistry::getInstance ( $mainframe->get ( 'component' ), $mainframe->get ( 'component' ) );
/* @var $registry bfRegistry */

/* Set the Page Generator Meta Tag */
bfDocument::setGenerator ( 'BFFramework' );

bfLoad ( 'bfChecks' );
$check = new bfChecks ( );
if ($check->runchecks () === false) {
	return;
}

/* Use Google CDN to load jQuery */
//bfDocument::addScript ( 'http://www.google.com/jsapi' );
bfDocument::addScript ( bfCompat::getLiveSite () . '/' . _PLUGIN_DIR_NAME . '/system/blueflame/libs/jquery/jquery.google_cdn.js' );

/* Spash Screen */
bfDocument::addScript ( bfCompat::getLiveSite () . '/' . _PLUGIN_DIR_NAME . '/system/blueflame/libs/jquery/jquery.splash.js' );
bfDocument::addstylesheet ( bfCompat::getLiveSite () . '/' . _PLUGIN_DIR_NAME . '/system/blueflame/libs/jquery/jquery.splash.css' );
//bfDocument::addstylesheet ( bfCompat::getLiveSite () . '/' . _PLUGIN_DIR_NAME . '/system/blueflame/libs/jquery/flexigrid/flexigrid.css' );

$pre = '../' . _PLUGIN_DIR_NAME . '/system/blueflame/bfCombine.php?type=js&c=' . $mainframe->get ( 'component_shortname' );
$name = $registry->getValue ( 'Component.Title' ) . ' v' . $registry->getValue ( 'Component.Version' );
$img = bfCompat::getLiveSite () . '/' . _PLUGIN_DIR_NAME . '/system/blueflame/view/loadingAnimation.gif';
$libs = bfCompat::getLiveSite () . '/' . _PLUGIN_DIR_NAME . '/system/blueflame/libs';
$r = <<<JJJJ

	function go(tOut){
		jQuery("#target").html('<div id="splash" style="display:none"><span class="appNameSpan"><br /><br /><h1 class="appName">$name</h1></span></div>');
		jQuery("#splash").splashQ({
			splashBox: "splash",
			scriptName: "JJJJJ",
			abortCallback: function(){ window.alert("Sorry its not working out for you, please contact us and we will help you!") },
			abortMsg: "Give Up and Get Help!",
			errorMsg: 'An error has occurred. <br /><br />This is probably a permissions issue on the folders or files listed below<br /><br />If you cannot fix this contact the Blue Flame developers for assistance',
			maxRetries: 3,
			timeout: tOut,
			scripts:
			[
				{name:"MooTools (If Needed)", src:"$pre&f=mootools"},
				{name:"jQuery Tabs", src:"$pre&f=jquery.tabs"},
				{name:"jQuery Thickbox", src:"$pre&f=jquery.thickbox_js"},
				{name:"jQuery Accordian", src:"$pre&f=jquery.accordion"},
				{name:"jQuery Growl", src:"$pre&f=jquery.growl"},
//				{name:"jQuery Facebox", src:"$pre&f=jquery.facebox"},
//				{name:"jQuery Flexigrid", src:"$pre&f=jquery.flexigrid"},
				{name:"Blue Flame Framework JS", src:"$pre&f=bfadmin_js"},
				{name:"Blue Flame Component JS", src:"$pre&f=admin_js"},
			]
		}
		);
		return true;
	}
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
	go(10000);

});
</script>
JJJJ;
bfDocument::addScriptFromString ( $r );

/* Load our Framework Javascript Lib and CSS */
bfDocument::addCSS ( bfCompat::getLiveSite () . '/' . _PLUGIN_DIR_NAME . '/system/blueflame/bfCombine.php?type=css&c=' . $mainframe->get ( 'component_shortname' ) . '&f=bfadmin_css,admin_css,jquery.growl.css,jquery.facebox.css' );

/* make admin mroe compatible with dodgy other component mambots */
if (_BF_PLATFORM == 'JOOMLA1.0') {
	$_MAMBOTS->loadBotGroup ( 'system' );
	
	$c = 0;
	if (count ( @$_MAMBOTS->_events ['onAfterStart'] )) {
		foreach ( $_MAMBOTS->_events ['onAfterStart'] as $trigger ) {
			
			/* Damage limitation for com_smf - SMF Bridge System Mambot */
			if ($trigger [0] == 'SMF_header_include') {
				unset ( $_MAMBOTS->_events ['onAfterStart'] [$c] );
			}
			
			/* JP Meta Edit hack */
			if ($trigger [0] == 'jpMetaEdit') {
				unset ( $_MAMBOTS->_events ['onAfterStart'] [$c] );
			}
			
			/* JP Meta Edit hack */
			if ($trigger [0] == 'bot_jstats_activate') {
				unset ( $_MAMBOTS->_events ['onAfterStart'] [$c] );
			}
			
			$c ++;
		}
	}
	$_MAMBOTS->trigger ( 'onAfterStart', array (true ), true );
	$_MAMBOTS->trigger ( 'xajax_onAfterStart', array (true ), true );
}

/* Set the Default Page Title - Should be overridden by xAJAX tasks Later */
bfDocument::setTitle ( $registry->getValue ( 'Component.Title' ) . ' v' . $registry->getValue ( 'Component.Version' ) );

/* include our other framework libs */
bfLoad ( 'bfController' );
bfLoad ( 'bfModel' );

/* Load the admin controller file */
require ($registry->getValue ( 'bfFramework_' . $mainframe->get ( 'component_shortname' ) . '.controller.admin' ));

/* Calculate the class name*/
$controller_class = $mainframe->get ( 'component' ) . 'Controller';

/* Create new controller object */
$controller = new $controller_class ( );
/* @var $controller bfController */

/* Set our component Name*/
/* @TODO cant we move this to the defaults in controller ? */
$controller->setComponentName ( $mainframe->get ( 'component' ) );

if (bfRequest::getVar ( 'tree', null ) !== null) {
	define ( '_POPUP', 0 );
	bfLoad ( 'bfJSTree' );
	$tree = new bfJSTree ( );
	
	$db = & bfCompat::getDBO ();
	$db->setQuery ( 'SELECT * FROM #__kb_categorys WHERE published = 1 ORDER BY title' );
	$parentcats = $db->loadObjectList ();
	
	$model = $controller->getModel ( 'article' );
	$articles = $model->getAll ();
	
	foreach ( $parentcats as $cat ) {
		$tree->_append ( $cat->id, $cat->parentid, $cat->title, '#' );
	}
	
	foreach ( $articles as $article ) {
		$catid = str_replace ( '|', '', $article->cid );
		$tree->_append ( $article->id * 100000, $catid, $article->title, '#' );
	}
	$tree->addJStoHEAD ();
	?>
<!--<TABLE border=0><TR><TD><FONT size=-2><A style="font-size:7pt;text-decoration:none;color:silver" href="http://www.treemenu.net/" target=_blank>Javascript Tree Menu</A></FONT></TD></TR></TABLE>-->
<div style="align: left"><script type="text/javascript">
<!--
// treeArray, startNode, openNode
// startNode and openNode are optional
createTree(Tree, 0, 4);
//-->
		</script></div>
<?php
	
	return;
}

$tmpl = bfRequest::getVar ( 'tmpl', null, 'REQUEST', 'STRING', 0 );

/* if Preview Mode */
if ($tmpl == 'component') {
	
	/* Set our registry flag */
	$registry->setValue ( 'isPopup', true );
	
	/* Set up our hidden div used for feedback messages and loading flash screen */
	//echo "<div id=\"tag-message\" style=\"display:none;\">\n\t<div class=\"loading\">Loading, Please wait ...</div>\n</div>";
	

	/* Load dependances */
	bfLoad ( 'bfHTML' );
	
	/* Set the args */
	$controller->setArguments ( bfRequest::get ( 'REQUEST' ), false );
	
	/* get our task */
	$task = bfRequest::getVar ( 'task', '', 'REQUEST' );
	
	/* execute the task */
	$controller->execute ( $task );
	
	/* render the view */
	$controller->renderView ();
	
	return;
}

/* Reset Our Session */
$bfsession->reset ();

/* Set up our hidden div used for feedback messages and loading flash screen */
echo '<div id="target"></div>'; //Splash Screen
echo '<iframe id="bf_iframe" name="bf_iframe" style="width: 0px; height: 0px;display:none;" src="about:blank"></iframe>';
if (_BF_PLATFORM == 'JOOMLA1.5') {
	/* Load editors js into head - only woks when editors are turned on in J config - loads of JS */
	/* @var $editor JEditor */
	jimport ( 'joomla.html.editor' );
	$conf = new JConfig ( );
	$instance = JEditor::getInstance ( $conf->editor );
	$instance->_loadEditor (); // Fudge
	$instance->initialise ();
} else {
	global $_MAMBOTS, $my, $mainframe;
	$user = bfUser::getInstance ();
	$my->params = $user->get ( 'params' ) ? $user->get ( 'params' ) : '';
	$my->gid = $user->get ( 'gid' ) ? $user->get ( 'gid' ) : '';
	include (bfCompat::getCfg ( 'absolute_path' ) . DS . 'editor' . DS . 'editor.php');
	$mainframe->set ( 'loadEditor', true );
	initEditor ();
}

/* specific for com_form */
if ($mainframe->get ( 'component' ) == 'com_form') {
	$formid = bfRequest::getVar ( 'form_id', '', 'REQUEST', 'int' );
	if ($formid) {
		$bfsession->set ( 'lastFormId', $formid, 'default' );
	} else {
		$bfsession->set ( 'lastFormId', '', 'default' );
	}
}

/* Set up our components main DIV on first page load - never needs to be done again */
bfHTML::displayAdminHeader ( $controller );

echo "\n<!-- Start of component div -->\n<div id=\"" . $mainframe->get ( 'component' ) . "\"></div>\n<!-- End of component div -->";

/* Add bfCopywrite */
echo "\n" . '<br /><div class="clear"></div>';

echo '<div id="bfCopyright">' . $registry->getValue ( 'Component.Title' ) . ' <b>v' . $registry->getValue ( 'Component.Version' ) . '</b> - bfFramework <b>v' . bfUtils::getFrameworkVersion () . '</b>';

echo ' <br /><a title="' . bfText::_ ( 'Visit our site' ) . '::' . bfText::_ ( 'Click here to visit the Blue Flame IT Ltd website for help support and updates' ) . '" class="hasTip" href="http://www.phil-taylor.com/in.php?' . bfCompat::getLiveSite () . '" target="_blank">&copy; ' . date ( 'Y' ) . ' Blue Flame IT Ltd.</a>  ';

echo '</div>';

/* Call our first xAJAX function to populate the newly built controlpanel with our default view */

$app = "\n\n" . '

function app(){
jQuery(document).ready(function(){

 			jQuery(\'#content-box\').hide();

           bfHandler(\'' . $registry->getValue ( 'bfFramework_' . $mainframe->get ( 'component_shortname' ) . '.defaultHomePageView' ) . '\');
           jQuery(\'#wrapper\').hide();
		   jQuery(\'.menudottedline\').hide();
		   jQuery.ready( function(){
		   jQuery(\'.footer\').remove();
		   jQuery(\'#footer\').remove();
		   ' . (_BF_PLATFORM == 'JOOMLA1.5' ? 'jQuery(\'#toolbar-box\').remove();' : '') . '
		   jQuery(\'#element-box > .t\').remove();
		   jQuery(\'#element-box > .b\').remove();
		   jQuery(\'#element-box > div\').attr(\'class\',\'\');
		   } );
		   jQuery(\'.footer\').remove();
		   jQuery(\'#footer\').remove();
		' . (_BF_PLATFORM == 'JOOMLA1.5' ? 'jQuery(\'#toolbar-box\').remove();' : '') . '
		' . (_BF_PLATFORM == 'JOOMLA1.5' ? 'jQuery(\'#border-top\').remove();' : '') . '
		' . (_BF_PLATFORM == 'JOOMLA1.5' ? 'jQuery(\'#module-menu\').remove();' : '') . '
		' . (_BF_PLATFORM == 'JOOMLA1.5' ? 'jQuery(\'span.loggedin-users\').remove();' : '') . '
		' . (_BF_PLATFORM == 'JOOMLA1.5' ? 'jQuery(\'span.preview\').html(\'\');' : '') . '
		' . (_BF_PLATFORM == 'JOOMLA1.5' ? 'jQuery(\'span.no-unread-messages\').remove();' : '') . '
		' . (_BF_PLATFORM == 'JOOMLA1.5' ? 'jQuery(\'#content-box > div\').attr(\'class\',\'\');' : '') . '
		' . (_BF_PLATFORM == 'JOOMLA1.5' ? 'jQuery(\'#module-status\').css(\'background\',\'none\');' : '') . '

		   jQuery(\'#element-box > .t\').remove();
		   jQuery(\'#element-box > .b\').remove();
		   jQuery(\'#element-box > div\').attr(\'class\',\'\');
		   jQuery(\'div.header\').css(\'padding-left\',\'0px\');
		   jQuery(\'#wrapper1\').prepend(\'<div><a class="hasTip" target="_blank" href="../index.php?option=' . $mainframe->get ( 'component' ) . '" title="Blue Flame::View The Frontend" class="hasTip"><img border="0" align="middle" alt="Blue Flame Extension" src="../' . bfCompat::mambotsfoldername () . '/system/blueflame/view/images/bullet-preview.gif"/></a></div>\');

		jQuery(\'.splashscreen_overlay\').fadeOut(\'slow\', function(e) {
										jQuery(\'.splashscreen_overlay\').remove();
									});
		jQuery(\'#target\').fadeOut(\'slow\', function(e) {
										jQuery(\'#target\').remove();
										jQuery(\'#content-box\').show();
									});
		if (\'undefined\'!= typeof(bfversioncheck)){
		eval(bfversioncheck);
		}
		});
};';

bfDocument::addScriptFromString ( $app );
if (_BF_PLATFORM == 'JOOMLA1.5') {
	echo '<div id="showjoomla" style="text-decoration: none; font-weight: bold;position: absolute; top: 17px; left: 15px;"><a href="index.php">
	<img src="../' . bfCompat::mambotsfoldername () . '/system/blueflame/view/images/door_in.png" align="absmiddle" border="0" /> ' . bfText::_ ( 'Exit To Joomla' ) . '</a></div>';
} else {
	echo '<div id="showjoomla" style="text-decoration: none; position: absolute; top: 5px; left: 560px;"><a href="#" onclick="jQuery(\'#wrapper\').toggle();jQuery(\'.menudottedline\').toggle();jQuery(\'.footer\').toggle();jQuery(this).blur();"><img src="../includes/js/ThemeOffice/joomla_16x16.png" boprder="0" align="absmiddle" style="padding-right: 3px;">Show Joomla</a></div>';
}

/* Keep session alive */
if (_BF_PLATFORM == 'JOOMLA1.5')
	JHTML::_ ( 'behavior.keepalive' );
