<?php
/**
 * @version $Id: bfSecurity.php 139 2010-01-03 20:45:41Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

/* If we are calling through xAJAX then get our args */
//@defined ( '_IS_XAJAX_CALL' ) ? $args = func_get_args () : $args = array ();

/* Check if we are logged in */
bfSecurity::checkLoginSession ();

/**
 * bfSecurity is a class with static methods that provide
 * security checks and functions
 */
class bfSecurity {
	
	/**
	 * Security check: All our xajax functions start with an x prefix so this
	 * Stops people calling our functions with XSS etc...
	 */
	function checkXFunction($args) {
		
		/* Get log */
		$log = & bfLog::getInstance ();
		$log->log ( 'bfSecurity: ... checking XFunction ...' );
		
		if (is_array ( $args ) && (count ( $args ) >= 1)) {
			$task = ( string ) bfSecurity::cleanVar ( $args [0], 0 );
		} else {
			$task = $args;
		}
		
		if (count ( $args ) && is_string ( $task )) {
			
			if (substr ( $task, 0, 1 ) != 'x') {
				$user = & bfUser::getInstance ();
				$log->log ( 'bfSecurity: ACCESS DENIED, xHandler task did not start with "x"' );
				$log->log ( 'bfSecurity: IP Address: ' . $_SERVER ['REMOTE_ADDR'] );
				$log->log ( 'bfSecurity: User: ' . $user->get ( 'id' ) . '::' . $user->get ( 'username' ) );
				if (_IS_XAJAX_CALL) {
					return false;
				} else {
					bfError::raiseError ( '403', 'Access Denied to Security.AdminController.' . $task );
				}
			} else {
				/* Check the framework config for access controls */
				if (bfSecurity::acl ( 'AdminController.' . $task, ' method ' . $task, false ) === false) {
					if (_IS_XAJAX_CALL) {
						return false;
					} else {
						bfError::raiseError ( '403', 'Access Denied to Security.AdminController.' . $task );
					}
				}
			}
		}
	}
	
	/**
	 * Security check: All our xajax functions start with an xpublic prefix so this
	 * Stops people calling our functions with XSS etc...
	 */
	function checkXPublicFunction($args) {
		
		/* Get log */
		$log = & bfLog::getInstance ();
		
		$task = ( string ) bfSecurity::cleanVar ( $args [0], 0 );
		
		if (count ( $args ) && is_string ( $task )) {
			$log->log ( 'bfSecurity: checking xhandler task: ' . $task . ' against security rules ...' );
			
			if (substr ( $task, 0, 7 ) != 'xpublic') {
				$user = & bfUser::getInstance ();
				$log->log ( 'bfSecurity: ACCESS DENIED, xHandler task did not start with "xpublic"' );
				$log->log ( 'bfSecurity: IP Address: ' . $_SERVER ['REMOTE_ADDR'] );
				$log->log ( 'bfSecurity: User: ' . $user->get ( 'id' ) . '::' . $user->get ( 'username' ) );
				if (_IS_XAJAX_CALL) {
					return false;
				} else {
					bfError::raiseError ( '403', 'Access Denied' );
				}
			} else {
				
				/* Check the framework config for access controls */
				if (bfSecurity::acl ( 'XAJAXFrontController.' . $task, ' method ' . $task, false ) === false) {
					if (_IS_XAJAX_CALL) {
						$log->log ( 'TEST:: ' . 'XAJAXFrontController.' . $task );
						return false;
					} else {
						bfError::raiseError ( '403', 'Access Denied to Security.XAJAXFrontController.' . $task );
					}
				}
			}
		}
	}
	
	/**
	 * I check if we are in administrator check we are logged in!
	 *
	 * @return bool
	 */
	function checkLoginSession() {
		/* Get log */
		
		/* Set up */
		if (bfCompat::isAdmin () && (_BF_TEST_MODE == false)) {
			$user = & bfUser::getInstance ();
			if ($user->get ( 'id' ) == 0) {
				
				/* We have no session, session expired, or logged out */
				
				/* Are we calling this from xAJAX calls ? */
				if (@defined ( '_IS_XAJAX_CALL' )) {
					// @TODO Does this do anything $objResponse is undefined!
					/* Display popup alert */
					$objResponse->alert ( bfText::_ ( 'Your sesion has expired, Please login again. ERR137' ) );
					/* Redirect back to admin login page */
					$objResponse->redirect ( bfURI::base () );
					/* Return XML to xAJAX */
					return $objResponse;
					/* just in case */
					die ();
				} else {
					bfRedirect ( bfCompat::getLiveSite (), bfText::_ ( 'Your sesion has expired, Please login again. ERR145' ) );
					/* just in case */
					die ();
				}
			}
		}
		return true;
	}
	
	/**
	 * @deprecated 
	 */
	function acl($acl, $what = null, $die = true) {
		return true;
	}
	
	/**
	 * @deprecated 
	 */
	function checkPermissions($acl, $what = null, $die = true) {
		return true;
	}
	
	/**
	 * Clean the input of some or any HTML depending on the
	 * input mask.
	 *
	 * @param string $var
	 * @param int $mask
	 * @param unknown_type $type
	 * @return unknown
	 */
	function cleanVar($var, $mask = 0, $type = null) {
		
		if (is_array ( $var )) {
			return $var;
		}
		
		$unclean = $var;
		// Static input filters for specific settings
		static $noHtmlFilter = null;
		static $safeHtmlFilter = null;
		
		//		$var = trim($var);
		

		switch ($mask) {
			// Now we handle input filtering
			case (2) :
				
				// If the allow raw flag is set, do not modify the variable
				$var = $var;
				break;
			case (4) :
				// If the allow html flag is set, apply a safe html filter to the variable
				

				break;
			default :
				// Since no allow flags were set, we will apply the most strict filter to the variable
				if (is_null ( $noHtmlFilter )) {
					$noHtmlFilter = & bfInputFilter::getInstance(/* $tags, $attr, $tag_method, $attr_method, $xss_auto */);
				}
//				$var = $noHtmlFilter->clean ( $var, $type );
				break;
		}
		
		if ($unclean != $var) {
			/* Log it*/
		}
		return $var;
	}

}
?>
