<?php
/**
 * @version $Id: bfDownload.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
 /*
 * Class has simple interface to download any file from a server
 * without displaying the location of the file
 *
 * Modified highly for bfFramework and Joomla Intergration
 *
 * @author Viatcheslav Ivanov, E-Witness Inc., Canada;
 * Mail ivanov@e-witness.ca;
 * @link  www.e-witness.ca; www.coolwater.ca; www.strongpost.net;
 * @version 1.1 /08.19.2002
 *
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );


class bfDownload {
	public $df_path = "";
	public $df_contenttype = "";
	public $df_contentdisposition = "";
	public $df_filename = "";
	public $result = true;

	/**
	 * BfDownload Constructor
	 *
	 * @param string $df_path
	 * @param string $df_contenttype
	 * @param string $df_contentdisposition
	 * @param string $df_filename
	 * @return bfDownload
	 */
	public function __construct($df_path, $df_contenttype = "application/zip", $df_contentdisposition = "attachment", $df_filename = "") {
		$this->df_path = $df_path;
		$this->df_contenttype = $df_contenttype;
		$this->df_contentdisposition = $df_contentdisposition;
		$this->df_filename = ($df_filename) ? $df_filename : basename ( $df_path );
	}

	/**
	 * Check is specified file exists?
	 *
	 * @return bool
	 */
	public function df_exists() {
		if (file_exists ( $this->df_path ))
			return true;
		return false;
	}

	/**
	 * get file size
	 *
	 * @return int Filesize
	 */
	public function df_size() {
		if ($this->df_exists ())
			return filesize ( $this->df_path );
		return false;
	}

	/**
	 * return permission number for user 'other'
	 *
	 * @return string Permission octal
	 */
	public function df_permitother() {
		return substr ( decoct ( fileperms ( $this->df_path ) ), - 1 );
	}

	/**
	 * Download the file
	 *
	 * @return string File Contents and Headers
	 */
	public function df_download() {
		if ($this->df_exists () && $this->df_permitother () >= 4) {

			header ( "Content-type: " . $this->df_contenttype );
			header ( "Content-Transfer-Encoding: binary" );
			header ( "Content-Disposition: " . $this->df_contentdisposition . "; filename=\"" . $this->df_filename . "\"" );
			header ( "Content-Length: " . $this->df_size () );

			$fp = readfile ( $this->df_path, "r" );
			return $fp;
		}
		return false;
	}
}