<?php
/**
 * @version $Id: bfString.php 117 2009-07-14 20:29:10Z  $
 * @package Blue Flame Framework (bfFramework)
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
defined ( '_JEXEC' ) or die ( 'Restricted access' );

/* utf8 should be here */
class bfString {
	
	/**
	 * PHP5 constructor
	 */
	function __construct() {
		throw new Exception ( 'bfString should not be instanted' );
	}
	
	public static function strtolower($format) {
		if (! class_exists ( 'Zend_Filter_StringToLower' ))
			require 'Zend/Filter/StringToLower.php';
		$Z_st = new Zend_Filter_StringToLower ( );
		return $Z_st->filter ( $format );
	}
	
	public static function strtoupper($str) {
		if (! class_exists ( 'Zend_Filter_StringToUpper' ))
			require 'Zend/Filter/StringToUpper.php';
		$Z_st = new Zend_Filter_StringToUpper ( );
		return $Z_st->filter ( $str );
	}
	
	public static function substr($str, $start, $len = null) {
		return substr ( $str, $start, $len );
	}
	
	public static function ucwords($str) {
		return ucwords ( $str );
	}
	
	public static function trim($str) {
		require_once 'Zend/Filter/StringTrim.php';
		$Z_st = new Zend_Filter_StringTrim ( );
		return $Z_st->filter ( $str );
	}
	
	public static function strlen($str) {
		return strlen ( $str );
	}
	/*
	 * Requires PHP 5 !!!
	 */
	public static function slug4mysql($unclean) {
		bfLoad ( 'bfUTF8' );
		$utf = new bfUtf8 ( );
		
		/* remove tags */
		require_once 'Zend/Filter/Alnum.php';
		require_once 'Zend/Filter/StripTags.php';
		require_once 'Zend/Filter/StringTrim.php';
		require_once 'Zend/Filter/StringToLower.php';
		$Z_st = new Zend_Filter_StripTags ( );
		$str = $Z_st->filter ( $unclean );
		$Z_st = new Zend_Filter_Alnum ( );
		$str = $Z_st->filter ( $str );
		$Z_st = new Zend_Filter_StringTrim ( );
		$str = $Z_st->filter ( $str );
		$Z_st = new Zend_Filter_StringToLower ( );
		$str = $Z_st->filter ( $str );
		
		/**
		 *
		 *
		 */
		$unPretty = array ('/á/', '/é/', '/í/', '/ó/', '/ú/', '/Á/', '/É/', '/Í/', '/Ó/', '/Ú/', '/ñ/', '/Ñ/', '/ü/', '/Ü/', '/ / ', '/í/', '/ñ/', '/\!/', '/\?/', '/:/', '/ä/', '/ö/', '/ü/', '/Ä/', '/Ö/', '/Ü/', '/ß/', '/\s?-\s?/', '/\s?_\s?/', '/\s?\/\s?/', '/\s?\\\s?/', '/\s/', '/"/', '/\'/' );
		$pretty = array ('/a/', '/e/', '/i/', '/o/', '/u/', '/A/', '/E/', '/I/', '/O/', '/U/', '/n/', '/N/', '/u/', '/U/', '_', 'i', 'n', '', '', '', 'ae', 'oe', 'ue', 'Ae', 'Oe', 'Ue', 'ss', '_', '_', '_', '_', '_', '', '' );
		
		$str = $utf->utf8ToHtmlEntities ( strtolower ( preg_replace ( $unPretty, $pretty, $str ) ) );
		$str = str_replace ( ' ', '', $str );
		$str = str_replace ( '`', '', $str );
		$str = str_replace ( '"', '', $str );
		$str = str_replace ( '£', '', $str );
		$str = str_replace ( '&pound;', '', $str );
		$str = str_replace ( '$', '', $str );
		$str = str_replace ( '%', '', $str );
		$str = str_replace ( '^', '', $str );
		$str = str_replace ( '&', '', $str );
		$str = str_replace ( '*', '', $str );
		$str = str_replace ( '(', '', $str );
		$str = str_replace ( ')', '', $str );
		$str = str_replace ( '{', '', $str );
		$str = str_replace ( '}', '', $str );
		$str = str_replace ( '@', '', $str );
		
		/* make sure the first item is not a number */
		$nums = array ('1', '2' . '3', '4', '5', '6', '7', '8', '9' );
		$first = substr ( $str, 0, 1 );
		if ($first == '0') {
			$str = '_' . $str;
		}
		$first = substr ( $str, 0, 1 );
		if (( int ) $first > 0) {
			$str = '_' . $str;
		}
		
		return $str;
	}
	
	public static function slug4sef($unclean, $spaceChar = '_') {
		bfLoad ( 'bfUTF8' );
		$utf = new bfUtf8 ( );
		
		/* remove tags */
		require_once 'Zend/Filter/Alnum.php';
		require_once 'Zend/Filter/StripTags.php';
		require_once 'Zend/Filter/StringTrim.php';
		require_once 'Zend/Filter/StringToLower.php';
		$Z_st = new Zend_Filter_StripTags ( );
		$str = $Z_st->filter ( $unclean );
		$Z_st = new Zend_Filter_Alnum ( true );
		$str = $Z_st->filter ( $str );
		$Z_st = new Zend_Filter_StringTrim ( );
		$str = $Z_st->filter ( $str );
		$Z_st = new Zend_Filter_StringToLower ( );
		$str = $Z_st->filter ( $str );
		
		/**
		 *
		 *
		 */
		$unPretty = array ('/á/', '/é/', '/í/', '/ó/', '/ú/', '/Á/', '/É/', '/Í/', '/Ó/', '/Ú/', '/ñ/', '/Ñ/', '/ü/', '/Ü/', '/ / ', '/í/', '/ñ/', '/\!/', '/\?/', '/:/', '/ä/', '/ö/', '/ü/', '/Ä/', '/Ö/', '/Ü/', '/ß/', '/\s?-\s?/', '/\s?_\s?/', '/\s?\/\s?/', '/\s?\\\s?/', '/\s/', '/"/', '/\'/' );
		$pretty = array ('/a/', '/e/', '/i/', '/o/', '/u/', '/A/', '/E/', '/I/', '/O/', '/U/', '/n/', '/N/', '/u/', '/U/', '_', 'i', 'n', '', '', '', 'ae', 'oe', 'ue', 'Ae', 'Oe', 'Ue', 'ss', '_', '_', '_', '_', '_', '', '' );
		
		$str = $utf->utf8ToHtmlEntities ( strtolower ( preg_replace ( $unPretty, $pretty, $str ) ) );
		$str = str_replace ( ' ', $spaceChar, $str );
		$str = str_replace ( '`', '', $str );
		$str = str_replace ( '"', '', $str );
		$str = str_replace ( '£', '', $str );
		$str = str_replace ( '&pound;', '', $str );
		$str = str_replace ( '$', '', $str );
		$str = str_replace ( '%', '', $str );
		$str = str_replace ( '^', '', $str );
		$str = str_replace ( '&', '', $str );
		$str = str_replace ( '*', '', $str );
		$str = str_replace ( '(', '', $str );
		$str = str_replace ( ')', '', $str );
		$str = str_replace ( '{', '', $str );
		$str = str_replace ( '}', '', $str );
		$str = str_replace ( '@', '', $str );
		
		return $str;
	}
	
	public static function strpos($str, $options = '') {
		return strpos ( $str, $options );
	}
}