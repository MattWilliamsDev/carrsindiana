<?php
/**
 * @version $Id: xajax.php 262 2009-03-20 02:41:35Z  $
 * @package Blue Flame Framework
 * @copyright Copyright (C) 2003,2004,2005,2006,2007,2008,2009 Blue Flame IT (Jersey) Ltd. All rights reserved.
 * @license GNU General Public License
 * @link http://www.blueflameit.ltd.uk
 * @author Phil Taylor / Blue Flame IT (Jersey) Ltd.
 *
 * bfFramework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * bfFramework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package.  If not, see http://www.gnu.org/licenses/
 */
if (defined ( '_VALID_MOS' ) or defined ( '_JEXEC' )) {
	/* ok we are in Joomla 1.0.x or Joomla 1.5+ */
	if (! defined ( '_VALID_MOS' )) {
		/* We are in Joomla 1.5 */
		if (! defined ( '_VALID_MOS' ))
			define ( '_VALID_MOS', '1' );
		if (! defined ( '_PLUGIN_DIR_NAME' ))
			define ( '_PLUGIN_DIR_NAME', 'plugins' );
		if (! defined ( '_BF_PLATFORM' ))
			define ( '_BF_PLATFORM', 'JOOMLA1.5' );
		if (! defined ( '_BF_JPATH_BASE' ))
			define ( '_BF_JPATH_BASE', JPATH_CONFIGURATION );
	} else if (! defined ( '_JEXEC' )) {
		/* we are in Joomla 1.0 */
		define ( '_JEXEC', '1' );
		if (! defined ( '_PLUGIN_DIR_NAME' ))
			define ( '_PLUGIN_DIR_NAME', 'mambots' );
		define ( '_BF_PLATFORM', 'JOOMLA1.0' );
		define ( 'JPATH_ROOT', $GLOBALS ['mosConfig_absolute_path'] );
		define ( '_BF_JPATH_BASE', $GLOBALS ['mosConfig_absolute_path'] );
		if (! defined ( 'DS' ))
			define ( 'DS', DIRECTORY_SEPARATOR );
	} else {
		if (defined ( '_VALID_MOS' ) or defined ( '_JEXEC' )) {
			/* Joomla 1.5 with legacy mode enabled*/
			/* We are in Joomla 1.5 */
			if (! defined ( '_VALID_MOS' ))
				define ( '_VALID_MOS', '1' );
			if (! defined ( '_PLUGIN_DIR_NAME' ))
				define ( '_PLUGIN_DIR_NAME', 'plugins' );
			if (! defined ( '_BF_PLATFORM' ))
				define ( '_BF_PLATFORM', 'JOOMLA1.5' );
			if (! defined ( '_BF_JPATH_BASE' ))
				define ( '_BF_JPATH_BASE', JPATH_CONFIGURATION );
		} else {
			die ( 'Unknown Platform- Contact Support' );
		}
	}
	if (! defined ( 'JPATH_SITE' ))
		define ( 'JPATH_SITE', $mosConfig_absolute_path );
	if (! defined ( 'DS' ))
		define ( 'DS', DIRECTORY_SEPARATOR );
	if (! defined ( '_JEXEC' ))
		define ( '_JEXEC', '1' );
	if (! defined ( 'BF_PLATFORM' ))
		define ( 'BF_PLATFORM', 'STANDALONE' );
	if (! defined ( 'JPATH_BASE' ))
		define ( 'JPATH_BASE', $GLOBALS ['mosConfig_absolute_path'] );

} else {
	header ( 'HTTP/1.1 403 Forbidden' );
	die ( 'Direct access not allowed' );
}

// Try to get the request URL
if (! empty ( $_SERVER ['REQUEST_URI'] )) {

	if (@ereg ( $_SERVER ['REQUEST_URI'], '' ))
		$_SERVER ['REQUEST_URI'] = str_replace ( array ('"', "'", '<', '>' ), array ('%22', '%27', '%3C', '%3E' ), $_SERVER ['REQUEST_URI'] );
}

$conflictingExtensions = array ();
$conflictingExtensions [] = 'com_wysiwygpro3';
$conflictingExtensions [] = 'com_jreviews';
$conflictingExtensions [] = 'com_comprofiler';
$conflictingExtensions [] = 'com_juser';
$conflictingExtensions [] = 'com_lqm';
$conflictingExtensions [] = 'com_admintodo';
$conflictingExtensions [] = 'com_rssfactory';
$conflictingExtensions [] = 'com_rssfactory_pro';
$conflictingExtensions [] = 'com_community';
$conflictingExtensions [] = 'com_sobi2';
$conflictingExtensions [] = 'com_idoblog';

/* Register the Plugin in Joomla */
if (_BF_PLATFORM == 'JOOMLA1.0') {

	if (! in_array ( mosGetParam ( $_REQUEST, 'option', null ), $conflictingExtensions ))
		$_MAMBOTS->registerFunction ( 'onAfterStart', '_LOAD_XAJAXJ10' );

} else {

	if (in_array ( JRequest::getCmd ( 'option' ), $conflictingExtensions ))
		return;

	class plgSystemXajax extends JPlugin {

		function plgSystemXajax($subject, $config) {

			parent::__construct ( $subject, $config );
		}

		function onAfterRoute() {

			/* if we are in a rss feed then dont do anything */
			$bannedFormats = array ('feed', 'pdf', 'raw', 'json' );
			if (in_array ( JRequest::getCmd ( 'format' ), $bannedFormats ))
				return;

			_LOAD_XAJAX_J15 ();

		}
	}
}

function _LOAD_XAJAXJ10() {

	global $mainframe, $xajaxFunctions;

	if (! defined ( 'XAJAX_VER' ))
		define ( 'XAJAX_VER', 'xajax' );
	if (! defined ( '_BF_JPATH_BASE' ))
		define ( '_BF_JPATH_BASE', $GLOBALS ['mosConfig_absolute_path'] );
	if (! defined ( 'DS' ))
		define ( 'DS', DIRECTORY_SEPARATOR );
	if (! defined ( 'XAJAX_ROOT' ))
		define ( 'XAJAX_ROOT', JPATH_ROOT . DS . _PLUGIN_DIR_NAME . DS . 'system' . DS . 'blueflame' );

	if (_BF_PLATFORM == 'JOOMLA1.0') {
		$no_html = mosGetParam ( $_REQUEST, 'no_html', null );
	} else {
		$no_html = JRequest::getVar ( 'no_html', '', 'REQUEST' );
	}
	if ($no_html)
		return;

	if (_BF_PLATFORM == 'JOOMLA1.0') {
		global $database;
	} else {
		$database = JFactory::getDBO ();
	}

	/* Require xAJAX */
	$file = XAJAX_ROOT . DS . XAJAX_VER . DS . 'xajax_core' . DS . 'xajax.inc.php';
	if (file_exists ( $file )) {
		require_once (XAJAX_ROOT . DS . XAJAX_VER . DS . 'xajax_core' . DS . 'xajax.inc.php');
	} else {
		return;
	}

	/* Instantiate the xajax object. */
	$xajax = new xajax ( );

	/* Get Configuration from params */
	if (_BF_PLATFORM == 'JOOMLA1.0') {
		$query = "SELECT params" . "\n FROM #__" . _PLUGIN_DIR_NAME . "\n WHERE element = 'xajax.system'" . "\n AND folder = 'system'";
		$database->setQuery ( $query );
		$database->loadObject ( $mambot );

		$pluginParams = new mosParameters ( $mambot->params );
	} else {
		$plugin = & JPluginHelper::getPlugin ( 'system', 'xajax.system' );
		$pluginParams = new JParameter ( $plugin->params );
	}

	/* Set defaults from params */
	$xajax->setCharEncoding ( $pluginParams->get ( 'encoding', 'UTF-8' ) );

	$pluginParams->get ( 'statusMessagesOn', '1' ) ? $xajax->setFlag ( 'statusMessages', true ) : $xajax->setFlag ( 'statusMessages', false );
	$pluginParams->get ( 'waitCursorOn', '1' ) ? $xajax->setFlag ( 'waitCursor', true ) : $xajax->setFlag ( 'waitCursor', false );
	$pluginParams->get ( 'debug', '0' ) ? $xajax->setFlag ( 'debug', true ) : $xajax->setFlag ( 'debug', false );
	$pluginParams->get ( 'decodeUTF8', '0' ) ? $xajax->setFlag ( 'decodeUTF8Input', false ) : $xajax->setFlag ( 'decodeUTF8Input', true );

	/* Locate and get PHP functions to wrap from the xAJAX file in each component (if exists) */
	$xajaxFunctions = array ();

	/* azrul: Look into all component folder and call xajax.component.php */
	$database->setQuery ( "SELECT `option` FROM #__components WHERE parent=0 AND iscore=0 " );
	$coms = $database->loadObjectList ();

	foreach ( $coms as $com ) {
		$base = JPATH_ROOT;
		$file = substr ( $com->option, 4 ) . '.php';

		/* Build path to file and filename */
		$xajaxFile = $base . DS . 'components' . DS . $com->option . DS . 'xajax.' . $file;

		$files [] = $xajaxFile;
		/* If file exists include it */
		if (file_exists ( $xajaxFile )) {
			include_once ($xajaxFile);
		}
	}

	if (! count ( $xajaxFunctions )) {
		return;
	}

	/* Register each function with xAJAX */
	foreach ( $xajaxFunctions as $call ) {
		if (is_array ( $call )) {
			/* xajax 0.2.4 */

			/* check function is now callable */
			if (is_callable ( $call [0] )) {

				/* Tell xajax about our function */
				$xajax->registerFunction ( $call [0] );
			}

		} else {
			/* xajax 0.5 */

			/* check function is now callable */
			if (is_callable ( $call )) {

				/* Tell xajax about our function */
				$xajax->registerFunction ( $call );
			}
		}
	}
	
	$url = preg_replace("/\/$/","",$mainframe->getCfg ( 'live_site' )); 

	/* get our url */
	if ($mainframe->isAdmin ()) {
		$reqURI = $url . '/' . _PLUGIN_DIR_NAME . '/system/blueflame/' . XAJAX_VER . '/' . "adminentry.php";
	} else {
		$reqURI = $url . '/' . _PLUGIN_DIR_NAME . '/system/blueflame/' . XAJAX_VER . '/' . "entry.php";
	}

	if (@$_SERVER ['HTTPS'] == 'on' && ereg ( 'http://', $url )) {
		$reqURI = str_replace ( 'http://', 'https://', $reqURI );
	}

	/* set the xAJAX request URL */
	$xajax->setRequestURI ( $reqURI );

	/* @var $document JDocument */
	global $mainframe;
	
	

	/* Get the xAJAX Javascript */
	$js = $xajax->getJavascript ( $url . '/' . _PLUGIN_DIR_NAME . '/system/blueflame/' . XAJAX_VER . '/' );

	$mainframe->addCustomHeadTag ( $js );

	/* set the users $my - legacy mode */
	global $my;

	/**
	 * Process any requests.  Because our requestURI is the same as our html page,
	 * this must be called before any headers or HTML output have been sent
	 **/

	$xajax->processRequest ();

}

/*Includes all the component xajax functions and outputs JS to Head */
function _LOAD_XAJAX_J15() {

	/* Set error reporting max */
	/* turn on error reporting */
	if ($_SERVER ['HTTP_HOST'] == '127.0.0.1' || $_SERVER ['HTTP_HOST'] == 'localhost') {
		error_reporting ( E_ALL );
		ini_set ( 'display_error', 1 );
	}

	/* Define xAJAX constants */

	if (! defined ( 'XAJAX_VER' ))
		define ( 'XAJAX_VER', 'xajax' );
	if (! defined ( '_BF_JPATH_BASE' ))
		define ( '_BF_JPATH_BASE', JPATH_ROOT );
	if (! defined ( 'DS' ))
		define ( 'DS', DIRECTORY_SEPARATOR );
	if (! defined ( 'XAJAX_ROOT' ))
		define ( 'XAJAX_ROOT', JPATH_ROOT . DS . _PLUGIN_DIR_NAME . DS . 'system' . DS . 'blueflame' );

	global $mainframe, $xajaxFunctions;

	$no_html = JRequest::getVar ( 'no_html', '', 'REQUEST' );
	if ($no_html)
		return;

	$c = JRequest::getVar ( 'tmpl' );
	if ($c == 'component')
		return;

	$database = & JFactory::getDBO ();

	/* Require xAJAX */
	$file = XAJAX_ROOT . DS . XAJAX_VER . DS . 'xajax_core' . DS . 'xajaxAIO.inc.php';
	if (file_exists ( $file )) {
		require_once (XAJAX_ROOT . DS . XAJAX_VER . DS . 'xajax_core' . DS . 'xajaxAIO.inc.php');
	} else {
		return;
	}

	/* Instantiate the xajax object. */
	$xajax = new xajax ( );

	/* Get Configuration from params */
	$plugin = & JPluginHelper::getPlugin ( 'system', 'xajax' );
	$pluginParams = new JParameter ( $plugin->params );

	/* Set defaults from params */
	$xajax->setCharEncoding ( $pluginParams->get ( 'encoding', 'UTF-8' ) );
	$pluginParams->get ( 'statusMessagesOn', '1' ) ? $xajax->setFlag ( 'statusMessages', true ) : $xajax->setFlag ( 'statusMessages', false );
	$pluginParams->get ( 'waitCursorOn', '1' ) ? $xajax->setFlag ( 'waitCursor', true ) : $xajax->setFlag ( 'waitCursor', false );
	$pluginParams->get ( 'debug', '0' ) ? $xajax->setFlag ( 'debug', true ) : $xajax->setFlag ( 'debug', false );
	$pluginParams->get ( 'decodeUTF8', '0' ) ? $xajax->setFlag ( 'decodeUTF8Input', false ) : $xajax->setFlag ( 'decodeUTF8Input', true );

	/* Locate and get PHP functions to wrap from the xAJAX file in each component (if exists) */
	$xajaxFunctions = array ();

	/* azrul: Look into all component folder and call xajax.component.php */
	$database->setQuery ( "SELECT `option` FROM #__components WHERE parent=0 AND iscore=0 " );
	$coms = $database->loadObjectList ();

	foreach ( $coms as $com ) {
		$base = JPATH_ROOT;
		$file = substr ( $com->option, 4 ) . '.php';

		/* Build path to file and filename */
		$xajaxFile = $base . DS . 'components' . DS . $com->option . DS . 'xajax.' . $file;

		$files [] = $xajaxFile;
		/* If file exists include it */
		if (file_exists ( $xajaxFile )) {
			include_once ($xajaxFile);
		}
	}

	if (! count ( $xajaxFunctions )) {
		return;
	}

	/* Register each function with xAJAX */
	foreach ( $xajaxFunctions as $call ) {
		if (is_array ( $call )) {
			/* xajax 0.2.4 */

			/* check function is now callable */
			if (is_callable ( $call [0] )) {

				/* Tell xajax about our function */
				$xajax->registerFunction ( $call [0] );
			}

		} else {
			/* xajax 0.5 */

			/* check function is now callable */
			if (is_callable ( $call )) {

				/* Tell xajax about our function */
				$xajax->registerFunction ( $call );
			}
		}
	}

	/* Get the xAJAX Javascript */
	$uri = & JFactory::getURI ();
	$url = str_replace ( '/administrator/', '', $uri->base () );
	$url = preg_replace("/\/$/","",$url); 

	if ($mainframe->isAdmin ()) {
		/* get our url */
		$reqURI = $url . '/administrator/' . "index.php";
	} else {
		$url = str_replace ( '/index.php', '', $url );
		$reqURI = $url . "/index.php";
	}

	/* set the xAJAX request URL */
	$xajax->setRequestURI ( $reqURI );
	
	$js = $xajax->getJavascript ( $url . '/' . _PLUGIN_DIR_NAME . '/system/blueflame/' . XAJAX_VER . '' );

	/* @var $doc JDocument */
	$doc = & JFactory::getDocument ();
	if (! method_exists ( $doc, 'addCustomTag' ))
		return;
	$doc->addCustomTag ( $js );

	/* set the users $my - legacy */
	global $my;

	/**
	 * Process any requests.  Because our requestURI is the same as our html page,
	 * this must be called before any headers or HTML output have been sent
	 **/
	$xajax->processRequest ();
}
?>
